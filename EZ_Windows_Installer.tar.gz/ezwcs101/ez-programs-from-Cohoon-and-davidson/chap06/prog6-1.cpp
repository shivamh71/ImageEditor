//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

// Compute area of a user-specified circle
#include <iostream.h>

// CircleArea(): compute area of circle of radius r
float CircleArea(float r) {
	const float Pi = 3.1415f;
	return Pi * r * r;
}

// main(): manage computation and display of the area of
// a user-specified circle
int main() {
	// prompt and read the radius
	float DesiredRadius;
	cout << "Circle radius (real number)? " << flush;
	cin >> DesiredRadius;

	// compute the area
	float Area = CircleArea(DesiredRadius);
	cout << "Area of circle with radius "
	<< DesiredRadius << " is " << Area << endl;

	// all done
	return 0;
}

