//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

// Compute size of a user-specified donut 
#include <iostream.h>

// prototyping
float DonutSize(float Outer, float Inner, float Width);
float CylinderVolume(float Radius, float Width);

// main(): manage computation and display of user-
// specified donut size
int main() {
	// prompt for donut dimensions
	cout << "Outer edge donut radius: " << flush;
	float OuterEdge;
	cin >> OuterEdge;
	cout << "Hole radius: " << flush;
	float InnerEdge;
	cin >> InnerEdge;
	cout << "Donut thickness: " << flush;
	float Thickness;
	cin >> Thickness;

	// compute and display the size of our donut
	cout << endl << "Size of donut with" << endl
	<< "   radius " << OuterEdge << endl
	<< "   hole radius " << InnerEdge << endl
	<< "   thickness " << Thickness << endl
	<< "is "
	<< DonutSize(OuterEdge, InnerEdge, Thickness)
	<< endl;

	return 0;
}

// DonutSize(): compute the size of a donut with outer
// edge radius Outer from the donut center, inner edge
// radius Inner from the donut center, and thickness
// Width
float DonutSize(float Outer, float Inner, float Width) {
	float OuterSize = CylinderVolume(Outer, Width);
	float HoleSize = CylinderVolume(Inner, Width);
	return OuterSize - HoleSize;
}

// CylinderVolume(): compute the size of a cylinder with
// radius r and height h
float CylinderVolume(float r, float h) {
	const float Pi = 3.1415f;
	return Pi * r * r * h;
}



