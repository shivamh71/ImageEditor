//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Computes area under the curve for a user-
// specified quadratic polynomial and x-interval 
#include <iostream.h>

// prototype
double QuadraticArea(double a2, double a1, double a0, double s, double t);
// main(): manage the computation of area under the 
// curve for a qaudratic polynomial
int main() {
	// prompt and extract quadratic polynomial
	cout << "Enter quadratic coefficients (a2 a1 a0): ";
	double a2;
	double a1;
	double a0;
	cin >> a2 >> a1 >> a0;
	// prompt and extract x-axis interval
	cout << "Enter interval of interest (n1 n2): ";
	double s;
	double t;
	cin >> s >> t;
	// compute and display area
	double Area = QuadraticArea(a2, a1, a0, s, t);
	cout << "The area of quadratic polynomial "
	 << a2 << "x*x + " << a1 << "x + " << a0
	 << " for the x-interval (" << s << ", " << t << ")"
	 << " is " << Area << endl;
	return 0;
}
// QuadraticArea(): compute area for a2*x*x + a1*x + a0
// for x-axis interval (s,t)
double QuadraticArea(double a2, double a1, double a0, double s, double t) {
	double term2 = a2*(t*t*t - s*s*s)/3.0;
	double term1 = a1*(t*t - s*s)/2.0;
	double term0 = a0*(t - s);
	return term2 + term1 + term0;
}

