//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.1 $
// $Name: $
//
//**************************************************************************

#include <iomanip.h>
#include <strstream.h>
#include "rect.h"
#include "label.h"
#include "utility.h"

using namespace std;

// utility constants
const float AxisThickness = 0.1;
const color AxisColor = Blue;
const float BarThickness = 0.5;
const color BarColor = Blue;
const float ChartXOffset = 1.5;
const float ChartYOffset = 2.0;

extern SimpleWindow W;

// GetFileName(): Prompt and extract filename
string  GetFileName() {
	cout << "Please enter file to be processed: "
	<< flush;
	string s;
	cin >> s;
	return s;
}

// Valid(): are weekly stock prices sensible
bool Valid(float low, float high) {
	return (0 <= low) && (low <= high);
}

// max: determine larger of its two parameters
int Max(int a, int b) {
	if (a < b)
		return b;
	else
		return a;
}


// ChartWeek(): Display current week's interval
void ChartWeek(int Week, float Low, float High) {
	float x = ChartXOffset + (Low + High)/2.0;
	float y = ChartYOffset + Week;
	float Length = High - Low;
	RectangleShape Bar(W, x, y, BarColor,Length,
	BarThickness);
	Bar.Draw();
	return;
}


// Display x-axis with labels
void DrawXAxis(string StockFile, float MaxX) {
	// draw axis
	float AxisLength = MaxX + 1;
	float CenterX = ChartXOffset + MaxX/2.0 + 0.5;
	float CenterY = ChartYOffset;
	RectangleShape Axis(W, CenterX, CenterY, AxisColor,
	AxisLength, AxisThickness);
	Axis.Draw();

	// display filename
	float FilenameX = CenterX;
	float FilenameY = ChartYOffset/4.0;
	Label Filename(W, FilenameX, FilenameY,
	StockFile.c_str());
	Filename.Draw();

	// display axis legend
	float LegendX = CenterX;
	float LegendY = ChartYOffset/2.0;
	Label Legend(W, LegendX, LegendY,
	"Weekly Low-High Price Interval");
	Legend.Draw();

	// display low label over axis
	float LowX = ChartXOffset + 1;
	float LowY = ChartYOffset/2.0 + 0.5;
	Label Low(W, LowX, LowY, "1");
	Low.Draw();

	// display high label over axis
	float HighX = ChartXOffset + MaxX;
	float HighY = ChartYOffset/2.0 + 0.5;
	ostrstream HighValue;
	HighValue << setw(3) << MaxX;
	Label High(W, HighX, HighY, HighValue.str());
	High.Draw();

	// all done
	return;
}


// DrawYAxis(): display y-axis with labels
void DrawYAxis(float MaxY) {
	// draw axis
	float CenterX = ChartXOffset;
	float CenterY = ChartYOffset + MaxY/2.0 + 0.5;
	float AxisLength = MaxY + 1;
	RectangleShape Axis(W, CenterX, CenterY, AxisColor,
	AxisThickness, AxisLength);
	Axis.Draw();

	// display legend
	float LegendX = ChartXOffset/2.0;
	float LegendY = CenterY;
	Label Legend(W, LegendX, LegendY, "Week");
	Legend.Draw();

	// display low label over axis
	float LowX = ChartXOffset/2.0 + 0.25;
	float LowY = ChartYOffset + 1;
	Label Low(W, LowX, LowY, "1");
	Low.Draw();

	// display high label over axis
	float HighX = ChartXOffset/2.0 + 0.25;
	float HighY = ChartYOffset + MaxY;
	ostrstream HighValue;
	HighValue << setw(3) << MaxY;
	Label High(W, HighX, HighY, HighValue.str());
	High.Draw();

	// all done
	return;
}


