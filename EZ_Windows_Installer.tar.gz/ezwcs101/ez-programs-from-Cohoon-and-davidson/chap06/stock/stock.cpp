//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include "utility.h"
#include "ezwin.h"
using namespace std;
 
// global window
SimpleWindow W("Stock Chart", 12, 9);

// ApiMain(): manage display of a stock chart
int ApiMain() {
	// extract filename and setup stream
	string StockFile = GetFileName();
	ifstream fin(StockFile.c_str());
	if (! fin) {
		cerr << "Cannot open: " << StockFile << endl;
		exit(1);
	}

	// setup
	W.Open();
	float StockHigh = 0;
	int WeekNbr = 0;

	// iteratively process stock-price intervals
	int WeeklyHigh;
	int WeeklyLow;
	while (fin >> WeeklyLow >> WeeklyHigh) {
		// have another week of data
		++WeekNbr;

		// check for valid data
		if (! Valid(WeeklyLow,WeeklyHigh)) {
			cerr << StockFile << ": Bad data for week "
			 << WeekNbr << endl;
			exit(1);
		}

		// chart it
		ChartWeek(WeekNbr, WeeklyLow, WeeklyHigh);

		// update the overall high if necessary
		StockHigh = Max((int)StockHigh, WeeklyHigh);
	}

	// display axes
	DrawXAxis(StockFile, StockHigh);
	DrawYAxis(WeekNbr);

	// all done
	return 0;
}



