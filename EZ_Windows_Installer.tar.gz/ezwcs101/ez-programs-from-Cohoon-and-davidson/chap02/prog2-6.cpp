//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Program 2.6: Compute the y coordinate of a
// point on a line given the line and an x coordinate
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 1/25/1996
#include <iostream.h>

int main() {
	// Input line�s parameters
	cout << "Slope of line (integer)? " << flush;
	int m; // Line slope		
	cin >> m;
	cout << "Intercept of x axis (integer)? " << flush;
	int b;		 // x intercept
	cin >> b;

	// Input x coordinate of interest
	cout << "X coordinate of interest (integer)? " << flush;
	int x;		 // x coordinate of interest
	cin >> x;

	// Compute and display y coordinate
	int y;
	y = m * x + b;
	cout << "y = " << y << " when m = " << m << ";";
	cout << " b = " << b << "; x = " << x << endl;

	return 0;
}

