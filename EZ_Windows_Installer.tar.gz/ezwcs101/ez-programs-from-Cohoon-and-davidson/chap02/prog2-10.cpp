//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

// Program 2.10: Compute area and circumference
// of circle given radius
#include <iostream.h>

int main() {

	cout << "Circle radius (real number)? " << flush;
	float Radius;// Radius of circle
	cin >> Radius;

	cout << "Area of circle with radius " << Radius
	 << " is " << (3.1415 * Radius * Radius) << endl;
	cout << "Circumference is " << 3.1415 * 2
	 * Radius << endl;

	return 0;
}
