//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

// Program 2.11: Compute velocity of car
#include <iostream.h>

int main() {
	cout << "All inputs are integers!\n";
	cout << "Start milepost? " << flush;
	int StartMilePost;
	cin >> StartMilePost;

	cout << "Elapsed time (hours minutes seconds)? "
	<< flush;
	int EndHour, EndMinute, EndSecond;
	cin >> EndHour >> EndMinute >> EndSecond;

	cout << "End milepost? " << flush;
	int EndMilePost;
	cin >> EndMilePost;

	float ElapsedTime = EndHour + (EndMinute / 60.0)
	+ (EndSecond / 3600.0);
	int Distance = EndMilePost - StartMilePost;
	float Velocity = Distance / ElapsedTime;

	cout << "\nCar traveled " << Distance
	 << " miles in ";
	cout << EndHour << " hrs " << EndMinute << " min "
	 << EndSecond << " sec\n";
	cout << "Average velocity was " << Velocity << " mph"
	 << endl;
	return 0;
}
