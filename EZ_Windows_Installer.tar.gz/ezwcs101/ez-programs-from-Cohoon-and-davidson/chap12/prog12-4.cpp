//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

// Displays a file in either upper- or  
// lowercase depending upon a user request.
#include <fstream>
#include <iostream>
#include <string>
#include <ctype.h>

using namespace std;

// Display(): display text stream using ToFunc
// modification
void Display(ifstream &fin, int (*ToFunc)(int c)) {
	// extract and display characters one-at-a-time
	char CurrentChar;
	while (fin.get(CurrentChar)){
		// modify current character using ToFunc
		CurrentChar = (*ToFunc)(CurrentChar);
		cout << CurrentChar;
	}
	return;
}
// main(): manage file stream display
int main() {
	const int MaxFileNameSize = 256;
	// prompt and extract the name of the file
	cout << "Enter name of file: " << flush;
	char FileName[MaxFileNameSize];
	cin >> FileName;
	// make sure a valid filename was provided
	ifstream fin(FileName);
	if (fin) {
		// we have valid file, so determine the action
		cout << "Display file in uppercase or "
		<< "lowercase (u, l):" << flush;
		char reply;
		cin >> reply;
		// display file according to request
		if (reply == 'l')
			Display(fin, tolower);
		else if (reply == 'u')
			Display(fin, toupper);
		else {
			cerr << "Bad request" << endl;
			return 1;
		}
	}
	else {// process invalid filename
		cerr << "Invalid file name: " << FileName
		 << endl;
		return 1;
	}
	return 0;
}

