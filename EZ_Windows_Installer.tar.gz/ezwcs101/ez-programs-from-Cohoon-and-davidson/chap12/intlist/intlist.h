
#ifndef INTLIST_H
#define LIST_H

#include <iostream>
#include <string>

using namespace std;

class IntList {
	public:
		// default constructor
		IntList(int n = 10, int val = 0);
		// constructor initializes from a standard array
		IntList(const int A[], int n);
		// copy constructor
		IntList(const IntList &A);
		// destructor
		~IntList();
		// assignment operator
		IntList& operator=(const IntList &A);
		// inspector for element of a constant list
		int operator[](int i) const;
		// inspector for element of a nonconstant list
		int& operator[](int i);
		// inspector for size of the list
		int size() const { return NumberValues; }
		// resize function
		void resize(int n = 0, int val = 0);
		// append a new element
		void push_back(int val);
	private:
		// data members
		int NumberValues;// size of list
		int *Values;// pointer to list elements
};

// auxiliary insertion operator for IntList
ostream& operator<<(ostream &sout, const IntList &A);


#endif

