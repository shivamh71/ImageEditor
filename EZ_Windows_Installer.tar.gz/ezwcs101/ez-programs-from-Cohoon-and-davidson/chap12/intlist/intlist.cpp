
#include <assert.h>

#include "intlist.h"

// constructor initializes elements to given value
IntList::IntList(int n, int val) {
	assert(n > 0);
	NumberValues = n;
	Values = new int [n];
	assert(Values);
	for (int i = 0; i < n; ++i) {
		Values[i] = val;
	}
}

// copy constructor
IntList::IntList(const IntList &A) {
	NumberValues = A.size();
	Values = new int [NumberValues];
	assert(Values);
	for (int i = 0; i < A.size(); ++i)
		Values[i] = A[i];
}

// destructor
IntList::~IntList() {
	delete [] Values;
}

// inspector of an individual const IntList element 
int IntList::operator[](int i) const {
	assert((i >= 0) && (i < size()));
	return Values[i];
}

// inspector/mutator facilitator of individual non-const element
int& IntList::operator[](int i) {
	assert((i >= 0) && (i < size()));
	return Values[i];
}

// assignment
IntList& IntList::operator=(const IntList &A) {
	if (this != &A) {
		if (size() != A.size()) {
			delete [] Values;
			NumberValues = A.size();
         Values = new int [A.size()];
			assert(Values);
		}
		for (int i = 0; i < A.size(); ++i)
			Values[i] = A[i];
	}
	return *this;
}

// auxiliary insertion operator for IntList
ostream& operator<<(ostream &sout, const IntList &A){
	sout << "[ ";
	for (int i = 0; i < A.size(); ++i)
		sout << A[i] << " ";
	sout << "]";
	return sout;
}
