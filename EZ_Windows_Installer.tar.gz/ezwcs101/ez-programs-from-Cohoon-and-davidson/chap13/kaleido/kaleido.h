//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#ifndef KALEIDOSCOPE_H
#define KALEIDOSCOPE_H

#include "ezwin.h"
#include "square.h"
#include "circle.h"
#include "triangle.h"
#include "randint.h"

class Kaleidoscope {
	public:
		Kaleidoscope(SimpleWindow &w, int Speed = 1000);
		int GetSpeed();
      SimpleWindow& GetWindow() const;
		int Turn();  // Turn the kaleidoscope so a
						 // new image is produced
	private:
		// constants and types
		enum {ShapesPerTurn = 4, NumberOfShapeTypes = 3 };
		enum ShapeType {CircleType, SquareType, TriangleType};
		// member functions
		float RandomOffset(int Range, float ShapeSize);
		// member data
		SimpleWindow &Window;  // Window that contains this kaleidoscope
		int Speed;  // Speed in uSec to update window
		CircleShape CircleTrinket;
		SquareShape SquareTrinket;
		TriangleShape TriangleTrinket;
		RandomInt RandomShape; // generate a random shape
		RandomInt RandomColor; // generate a random color
};
#endif
