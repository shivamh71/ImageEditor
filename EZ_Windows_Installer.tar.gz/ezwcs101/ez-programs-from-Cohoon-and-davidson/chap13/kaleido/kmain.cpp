//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include <stdlib.h>
#include "ezwin.h"
#include "kaleido.h"

// Instantiate a  window to display the kaleidoscope
SimpleWindow KWindow("Kaleidoscope", 10.0, 10.0,
Position(2.0, 2.0));

// Instantiate a kaleidoscope named Kscope that will
// turn once a second
Kaleidoscope KScope(KWindow, 1000);

// DispatchTimerClick(): call the Kscope's turn function
int DispatchTimerClick() {
	KScope.Turn();
	return 1;
}

// ApiMain(): open the window, set up the call back,
// and start the timer
int ApiMain() {
   EzRandomize();
	KWindow.Open();
	KWindow.SetTimerCallback(DispatchTimerClick);
	KWindow.StartTimer(KScope.GetSpeed());

	return 0;
}

// ApiEnd(): clean up by closing KWindow
int ApiEnd() {
	KWindow.Close();
	return 0;
}

