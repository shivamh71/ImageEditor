//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

//
// Kaleidoscope module
//

#include <assert.h>
#include <iostream>
#include <string>
#include <vector>
#include "kaleido.h"

using namespace std;

// Kaleidscope(): constructor for kaleidoscope
Kaleidoscope::Kaleidoscope(SimpleWindow &w,
 int s) : Window(w), Speed(s),
 CircleTrinket(w, Position(0, 0)),
 SquareTrinket(w, Position(0, 0)),
 TriangleTrinket(w, Position(0, 0)),
 RandomColor(0, MaxColors - 1),
 RandomShape(0, NumberOfShapeTypes - 1) {
	assert(&w != NULL);
}

// GetSpeed(): return the speed
int Kaleidoscope::GetSpeed() {
	return Speed;
}

// GetWindow(): return the Window containing the
// kaleidoscope
SimpleWindow& Kaleidoscope::GetWindow() const {
	return Window;
}

// RandomOffset(): generate a random amount to offset a
// square from the center of the window. Generate a
// random offset from the
// interval 0..Range-1 in .1 centimeter increments.
// The offset generated must take into account
// the size of the shape so the shapes do not
// overlap at the center.
float Kaleidoscope::RandomOffset(int Range,
 float ShapeSize) {
	RandomInt R(0, Range * 10);
	float offset = R.Draw() / 10.0;
	// if offset is not large enough to keep
	// the shape from overlapping set the offset
	// to half the shape size
	if (offset < ShapeSize / 2)
		 offset = ShapeSize / 2;
	return offset;
}

// Turn(): turn the kaleidoscope
int Kaleidoscope::Turn() {

	// Get logical coordinates of the center of the window
//	const Position CenterOfWindow = Position(5.0, 5.0);
   const Position CenterOfWindow = Window.GetCenter();
//   float test1 = Window.GetWidth();
//   float test2 = Window.GetHeight();
//   Position test3 = Window.GetCenter();
//   float test4 = test3.GetXDistance();
//   float test5 = test3.GetYDistance();

//   cout << test1 << " " << test2 << " " << test4 << " " << test5 << endl;

	// The largest shape should be 1 centimeter smaller than
	// half the size of the window
	const float MaxShapeSize =
	 (Window.GetWidth() / 2.0) - 1.0;
//	const float MaxShapeSize =
//	 (10 / 2.0) - 1.0;

	// The largest offset should be 1 centimeter smaller
	// than half the size of the window
	const float MaxOffset =
	 (Window.GetWidth() / 2.0) - 1.0;
//	const float MaxOffset =
//	 (10 / 2.0) - 1.0;

	// Create four shapes, one in each quadrant. All shapes
	// are the same size. However, size is picked randomly.
	// The colors of the shapes are also also chosen randomly.
	// The shapes in diagonally opposite quadrants are
	// the same color.
   vector<color> ShapeColor(2);
   ShapeColor[0] = (color) RandomColor.Draw();
   ShapeColor[1] = (color) RandomColor.Draw();

	// Generate a random size in the interval
	// 1 to MaxShapeSize in .1 centimeter increments
	// (i.e., 1, 1.1, 1.2, ...
	RandomInt RandomShapeSize(10, MaxShapeSize * 10);
	const float ShapeSize = RandomShapeSize.Draw() / 10.0;

	// Generate an amount to offset the squares from the
	// center point of the window.
	const float Offset = RandomOffset(MaxOffset, ShapeSize);

	// Compute and create the four positions to draw the shapes
   vector<Position> ShapeLocation(ShapesPerTurn);
   ShapeLocation[0] = CenterOfWindow + Position( Offset, -Offset);
   ShapeLocation[1] = CenterOfWindow + Position(-Offset, -Offset);
   ShapeLocation[2] = CenterOfWindow + Position(-Offset,  Offset);
   ShapeLocation[3] = CenterOfWindow + Position( Offset,  Offset);

	// Pick a kind of shape to draw
	const ShapeType KindOfShape = (ShapeType) RandomShape.Draw();

		if (KindOfShape == CircleType) {
			for (int i = 0; i < ShapesPerTurn; ++i) {
				CircleTrinket.SetPosition(ShapeLocation[i]);
				CircleTrinket.SetColor(ShapeColor[i % 2]);
				CircleTrinket.SetSize(ShapeSize);
				CircleTrinket.Draw();
			}
		}
		else if (KindOfShape == SquareType) {
			for (int i = 0; i < ShapesPerTurn; ++i) {
				SquareTrinket.SetPosition(ShapeLocation[i]);
				SquareTrinket.SetColor(ShapeColor[i % 2]);
				SquareTrinket.SetSize(ShapeSize);
				SquareTrinket.Draw();
			}
		}
		else if (KindOfShape == TriangleType) {
			for (int i = 0; i < ShapesPerTurn; ++i) {
				TriangleTrinket.SetPosition(ShapeLocation[i]);
				TriangleTrinket.SetColor(ShapeColor[i % 2]);
				TriangleTrinket.SetSize(ShapeSize);
				TriangleTrinket.Draw();
			}
		}
	return 1;
}

