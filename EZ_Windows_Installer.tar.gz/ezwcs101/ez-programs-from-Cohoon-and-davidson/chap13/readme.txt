The source code for the implementations of the shapes presented
in Chapter 13 (Inheritance) can be found in the ezwin\src directory.