//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

// Display a dream house
#include <iostream>
#include "shape.h"
#include "triangle.h"
#include "circle.h"
#include "rect.h"
#include "square.h"
#include "slist.h"

using namespace std;

// prototypes
SeqList<Shape*>* BuildHouse(SimpleWindow &W);
void DrawFigure(SeqList<Shape*> *F);

SimpleWindow window("House", 10, 10);

// ApiMain(); manage building and display of house
int ApiMain() {
	window.Open();
	SeqList<Shape*> *DreamHouse = BuildHouse(window);
	DrawFigure(DreamHouse);

	return 0;
}

// BuildHouse(): use basic shapes to make a house
SeqList<Shape*>* BuildHouse(SimpleWindow &W) {
	// House composed of a list of parts
	SeqList<Shape*> *House = new SeqList<Shape*>;

	
	House->push_back( // house has a square frame
		new SquareShape(W, Position(5, 7), Blue, 5)
	);

	House->push_back( // house has a triangular roof
		new TriangleShape(W, Position(5, 3), Red, 5)
	);

	House->push_back( // house has a skylight
		new CircleShape(W, Position(5, 7.75), Yellow, 1.5)
	);
	
	House->push_back( // house has a door
		new RectangleShape(W, Position(5, 8.5), Yellow,
		1.5, 2)
	);
	
	House->push_back( // house a left window
		new SquareShape(W, Position(4,6), Yellow, 1.5)
	);
	
	House->push_back( // house has a right window
		new SquareShape(W, Position(6,6), Yellow, 1.5)
	);

	return House;
}

// DrawFigure(): draw shapes in list F
void DrawFigure(SeqList<Shape*> *F) { 
	for (SeqIterator<Shape*> P = F->begin(); P; ++P) {
		(*(*P)).Draw();
	}
}


