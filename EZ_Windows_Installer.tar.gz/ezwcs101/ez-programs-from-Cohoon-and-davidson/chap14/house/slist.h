//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#ifndef SLIST_H
#define SLIST_H

#include <iostream>
#include <string>
#include <assert.h>

using namespace std;

template <class T> class SeqList;
template <class T> class SeqIterator;
template <class T> class ConstSeqIterator;

template<class T>
class SeqItem{
	friend class SeqList<T>;
	friend class SeqIterator<T>;
	friend class ConstSeqIterator<T>;
	protected:
		// default constructor
		SeqItem(const T &val)
		 : ItemValue(val), Predecessor(0), Successor(0) {
			// no code needed
		};
	private:
		T ItemValue;// element value
		SeqItem *Predecessor;// pointer to previous element
		SeqItem *Successor;// pointer to next element
};

template<class T>
class SeqList {
	friend class SeqIterator<T>;
	friend class ConstSeqIterator<T>;
	public:
		typedef SeqIterator<T> iterator;
		typedef ConstSeqIterator<T> const_iterator;
		SeqList();
		~SeqList();
		int size() const;
		T& front();
		const T& front() const;
		T& back();
		const T& back() const;
		iterator begin();
		const_iterator begin() const;
		iterator end();
		const_iterator end() const;
		void push_back(const T &val);
		void pop_front();
		void display(ostream &sout) const;
		iterator insert(iterator p, const T &val);
		iterator erase(iterator p);
		void clear();
		SeqList& operator=(const SeqList &S);
		SeqList(const SeqList<T> &S);
	private:
		SeqItem<T> *Front;  // pointer to first element
		SeqItem<T> *Back;   // pointer to last element
		int ListLength;     // number of elements
};

template<class T>
class SeqIterator {
	friend class SeqList<T>;
	public:
		// default constructor
		SeqIterator();
		// specific constructor 
		SeqIterator(SeqList<T> &L);
		// mutate to next element in list
		SeqIterator<T>& operator++();// prefix version
		SeqIterator<T> operator++(int);// postfix version
		// mutate to previous element in list
		SeqIterator<T>& operator--();// prefix version
		SeqIterator<T> operator--(int);// postfix version
		// inspector for a constant iterator
		const T& operator*() const;
		// inspector/mutator for a nonconstant iterator
		T& operator*();
		// test for equality
		bool operator==(const SeqIterator<T> &p) const;
		// test for inequality
		bool operator!=(const SeqIterator<T> &p) const;
		// bool cast
		operator bool() const;
	protected:
		// specific constructor for SeqList use
		SeqIterator(SeqList<T> *P, SeqItem<T> *q);
	private:
		SeqList<T> *ThisList;// pointer to iterated list
		SeqItem<T> *ItemPtr;// pointer to current element
};

// prototype for auxiliary insertion operator for SeqList
template <class T> ostream& operator<<(ostream& sout, const SeqList<T> &L);

// default SeqList constructor
template<class T>
SeqList<T>::SeqList()
 : ListLength(0), Front(0), Back(0) { // no code needed
}

// SeqList destructor 
template<class T>
SeqList<T>::~SeqList() {
	clear();
}

// size(): return size of list 
template<class T>
int SeqList<T>::size() const {
	return ListLength;
}

// front(): return reference to first element in list 
template<class T>
T& SeqList<T>::front() {
	assert(size() != 0);
	return Front->ItemValue;
}

// front(): return const reference to first element in list 
template<class T>
const T& SeqList<T>::front() const {
	assert(size() != 0);
	return Front->ItemValue;
}

// back(): return reference to last element in list 
template<class T>
T& SeqList<T>::back() {
	assert(size() != 0);
	return Back->ItemValue;
}

// back(): return const reference to last element in list 
template<class T>
const T& SeqList<T>::back() const {
	assert(size() != 0);
	return Back->ItemValue;
}

// begin(): create iterator pointing to first element
template<class T>
SeqIterator<T> SeqList<T>::begin() {
	return SeqIterator<T>(this, Front);
}

// end(): create iterator pointing to sentinel
template<class T>
SeqIterator<T> SeqList<T>::end() {
	return SeqIterator<T>(this, 0);
}

// push_back(): add value to end of list
template<class T>
void SeqList<T>::push_back(const T &val) {
	insert(end(), val);
}

// pop_front(): erase value from front of list
template<class T>
void SeqList<T>::pop_front() {
	erase(begin());
}

// display(): display list
template<class T>
 void SeqList<T>::display(ostream &sout) const {
	sout << "[";
	for (SeqItem<T> *Ptr = Front; Ptr; Ptr = Ptr->Successor) {
		sout << " " << Ptr->ItemValue;
	}
	sout << "]";
}

// insert(): add an item to the list
template<class T>
SeqIterator<T> SeqList<T>::insert(SeqIterator<T> p, const T &val) {
	// make sure the iterator belongs to this list
	assert(p.ThisList == this);
	// create the item to represent our new element
	SeqItem<T> *curr = new SeqItem<T>(val);
	assert(curr);
	if (p.ItemPtr != 0) { // new item is not the rear
		// determine successor and predecessor of new item
		SeqItem<T> *succ = p.ItemPtr;
		SeqItem<T> *pred = succ->Predecessor;
		// reset links to reflect the changes to the list
		curr->Successor = succ;
		curr->Predecessor = pred;
		succ->Predecessor = curr;
		// determine whether new item is to head the list
		if (succ == Front) { // yes it does
			Front = curr;
		}
		else { // no it does not
			pred->Successor = curr;
		}
	}
	else { // iterator p does not point to a list element
		if (size() == 0) { // curr is the list at this point
			Front = Back = curr;
		}
		else { // curr is to be the end of the list
			curr->Predecessor = Back;
			Back->Successor = curr;
			Back = curr;
		}
	}
	// reflect that the item has been added
	++ListLength;
	// bring back an iterator to the new item
	return SeqIterator<T>(this, curr);
}

// erase(): remove an item from list
template<class T>
SeqIterator<T> SeqList<T>::erase(SeqIterator<T> p) {
	// make sure the iterator belongs to this list
	assert(p.ThisList == this);
	// make sure the iterator points to an item
	assert(p.ItemPtr);
	// identify item and its neighbors (if any)
	SeqItem<T> *curr = p.ItemPtr;
	SeqItem<T> *pred = curr->Predecessor;
	SeqItem<T> *succ = curr->Successor;
	// determine whether item heads list
	if (curr == Front) { // yes it does
		// successor (if any) now heads the list
		Front = succ;
	}
	else { // no it doesn�t
		// predecessor should point to its successor (if any)
		pred->Successor = succ;
	}
	// determine whether item ends the list
	if (curr == Back) { // yes it does
		// predecessor (if any) now ends the list
		Back = pred;
	}
	else { // no it doesn�t
		// successor should point to its predecessor (if any)
		succ->Predecessor = pred;
	}
	// can delete the item -- its neighborhood is updated
	delete curr;
	// reflect that the item has been removed
	--ListLength;
	// bring back an iterator to the successor (if any)
	return SeqIterator<T>(this, succ);
}

// clear(): purge list
template<class T>
void SeqList<T>::clear() {
	SeqItem<T> *Ptr = Front;
	while ( Ptr ) {
		SeqItem<T> *Next = Ptr->Successor;
		delete Ptr;
		Ptr = Next;
	}
	Front = Back = 0;
	ListLength = 0;
}

// SeqIterator(): default constructor
template<class T>
 SeqIterator<T>::SeqIterator() : ThisList(0), ItemPtr(0) {
	// no code needed
}

// SeqIterator(): specific public constructor
template<class T>
 SeqIterator<T>::SeqIterator(SeqList<T> &L)
  : ThisList(&L), ItemPtr(L.Front) { // no code needed
}

// SeqIterator(): specific protected constructor
template<class T>
 SeqIterator<T>::SeqIterator(SeqList<T> *P, SeqItem<T> *q)
  : ThisList(P), ItemPtr(q) { // no code needed
}

// ++: produce successor (prefix version)
template<class T>
 SeqIterator<T>& SeqIterator<T>::operator++() {
	assert(ItemPtr != 0);
	ItemPtr = ItemPtr->Successor;
	return *this;
}

// ++: produce successor (postfix version)
template<class T>
 SeqIterator<T> SeqIterator<T>::operator++(int) {
	assert(ItemPtr != 0);
	SeqIterator<T> remember(*this);
	ItemPtr = ItemPtr->Successor;
	return remember;
}

// *: inspector for a constant iterator
template<class T> 
 const T& SeqIterator<T>::operator*() const {
	assert(ItemPtr != 0);
	return ItemPtr->ItemValue;
}

// *: inspector/mutator for a nonconstant iterator
template<class T> T& SeqIterator<T>::operator*() {
	assert(ItemPtr != 0);
	return ItemPtr->ItemValue;
}

// ==: do the iterators refer to the same element
template<class T>
bool SeqIterator<T>::operator==(const SeqIterator<T> &p) const {
	return ItemPtr == p.ItemPtr;
}

// !=: do the iterators refer to different elements
template<class T>
bool SeqIterator<T>::operator!=(const SeqIterator<T> &p) const {
	return ! (*this == p);
}

// bool: cast indicates whether the iterarator points to an
// element
template<class T>
SeqIterator<T>::operator bool () const {
	return *this != this->ThisList->end();
}

// <<: overload insertion operator for list iterator
template<class T>
ostream& operator<<(ostream &sout, const SeqIterator<T> &a) {
	return sout << *a;
}

#endif
