//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#ifndef SHAPE_H
#define SHAPE_H

#include "wobject.h"
class Shape : public WindowObject {
	public:
		Shape(SimpleWindow &w, const Position &p,
		const color c = Red);
		color GetColor() const;
		void SetColor(const color c);
		virtual void Draw() = 0; // pure virtual function!
	private:
		color Color;
};

#endif

