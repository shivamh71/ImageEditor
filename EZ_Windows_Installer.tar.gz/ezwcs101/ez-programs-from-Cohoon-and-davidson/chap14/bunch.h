//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#ifndef BUNCH_H
#define BUNCH_H

template<class T, int n>
 class Bunch {
	public:
		// default constructor
		Bunch();
		// constructor initializes all elements to val
		Bunch(const T &val);
		// constructor initializes from standard array
		Bunch(const T A[n]);
		// inspector for number of elements in list
		int size() const { return NumberValues; } ;
		// inspector for element of constant list
		const T& operator[](int i) const;
		// inspector for element of nonconstant list
		T& operator[](int i);
	private:
		// data members
		T Values[n];// list elements
		int NumberValues; // size of list
};

#endif
