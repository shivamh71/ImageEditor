//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#ifndef ALIST_H
#define ALIST_H

#include <iostream>
#include <string>

using namespace std;

#include <assert.h>

template<class T>
 class Array {
	public:
		// default constructor initializes n elements to val
		Array(int n = 10 , const T &val = T());
		// specialized constructor using a standard array
		Array(const T A[], int n);
		// copy constructor
		Array(const Array<T> &A);
		// destructor
		~Array();
		// inspector for size of the list
		int size() const { return NumberValues; }
		// assignment operator
		Array<T> & operator=(const Array<T> &A);
		// inspector for element of constant list
		const T& operator[](int i) const;
		// inspector/mutator for element of nonconstant list
		T& operator[](int i);
	private:
		// data members
		int NumberValues; // size of list
		T *Values;// pointer to list elements
};

// default constructor initializes n elements to val
template<class T>
Array<T>::Array(int n, const T &val) {
	assert(n > 0);
	NumberValues = n;
	Values = new T [n];
	assert(Values);
	for (int i = 0; i < n; ++i) {
		Values[i] = val;
	}
}

// constructor initializes from a standard array
template<class T>
Array<T>::Array(const T A[], int n) {
	assert(n > 0);
	NumberValues = n;
	Values = new T [n];
	assert(Values);
	for (int i = 0; i < n; ++i) {
		Values[i] = A[i];
	}
}

// copy constructor
template<class T>
Array<T>::Array(const Array<T> &A) {
	NumberValues = A.size();
	Values = new T [A.size()];
	assert(Values);
	for (int i = 0; i < A.size(); ++i)
		Values[i] = A[i];
}
// destructor
template<class T>
Array<T>::~Array() {
	delete [] Values;
}
// assignment
template<class T> 
Array<T>& Array<T>::operator=(const Array<T> &A) {
	if (this != &A) {
		if (size() != A.size()) {
			delete [] Values;
			NumberValues = A.size();
			Values = new T [A.size()];
			assert(Values);
		}
		for (int i = 0; i < A.size(); ++i)
			Values[i] = A[i];
	}
	return *this;
}

// inspector of the value of an individual element
template<class T>
const T& Array<T>::operator[](int i) const {
	assert((i >= 0) && (i < size()));
	return Values[i];
}

// inspector/mutator facilitator of individual element
template<class T>
T& Array<T>::operator[](int i) {
	assert((i >= 0) && (i < size()));
	return Values[i];
}

// template insertion operator for Array
template<class T>
ostream& operator<<(ostream &sout, const Array<T> &A){
	sout << "[ ";
	for (int i = 0; i < A.size(); ++i) {
		sout << A[i] << " ";
	}
	sout << "]";
	return sout;
}

// insertion operator for Array<char>
ostream& operator<<(ostream &sout, const Array<char> &A) {
	for (int i = 0; i < A.size(); ++i) {
		sout << A[i];
	}
	return sout;
}

#endif
