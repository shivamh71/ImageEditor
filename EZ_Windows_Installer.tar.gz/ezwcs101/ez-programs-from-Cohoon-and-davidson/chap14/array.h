//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

#ifndef ARRAY_H
#define ARRAY_H

#include <iostream>
#include <assert>

template <class T> class Array {
	public:
		// default constructor
		Array(int n = 10);
		// constructor initializes elements to given value
		Array(int n, const T &val);
		// constructor initializes from a standard array
		Array(const T A[], int n);
		// copy constructor
		Array(const Array<T> &A);
		// destructor
		~Array();
		// inspector for size of the list
		int Size() const { return NumberValues; }
		// assignment operator
		Array<T> & operator=(const Array<T> &A);
		// inspector for element of a constant list
		const T& operator[](int i) const;
		// inspector for element of a nonconstant list
		T& operator[](int i);
	private:
		// data members
		T *Values;// pointer to list elements
		int NumberValues; // size of list
};

// default constructor
template <class T> Array<T>::Array(int n) {
	assert(n > 0);
	NumberValues = n;
	Values = new T [n];
	assert(Values);
}

// constructor initializes elements to given value
template <class T>
Array<T>::Array(int n, const T &val) {
	assert(n > 0);
	NumberValues = n;
	Values = new T [n];
	assert(Values);
	for (int i = 0; i < n; ++i) {
		Values[i] = val;
	}
}

// constructor initializes from a standard array
template <class T>
Array<T>::Array(const T A[], int n) {
	assert(n > 0);
	NumberValues = n;
	Values = new T [n];
	assert(Values);
	for (int i = 0; i < n; ++i) {
		Values[i] = A[i];
	}
}

// copy constructor
template <class T> Array<T>::Array(const Array<T> &A) {
	NumberValues = A.Size();
	Values = new T [A.Size()];
	assert(Values);
	for (int i = 0; i < A.Size(); ++i)
		Values[i] = A[i];
}
// destructor
template <class T> Array<T>::~Array() {
	delete [] Values;
}
// assignment
template <class T>
Array<T>& Array<T>::operator=(const Array<T> &A) {
	if (this != &A) {
		if (Size() != A.Size()) {
			delete [] Values;
			NumberValues = A.Size();
			Values = new T [A.Size()];
			assert(Values);
		}
		for (int i = 0; i < A.Size(); ++i)
			Values[i] = A[i];
	}
	return *this;
}

// inspector of the value of an individual element
template <class T>
const T& Array<T>::operator[](int i) const {
	assert((i >= 0) && (i < Size()));
	return Values[i];
}

// inspector/mutator facilitator of individual element
template <class T>
T& Array<T>::operator[](int i) {
	assert((i >= 0) && (i < Size()));
	return Values[i];
}

// template insertion operator for Array
template <class T>
ostream& operator<<(ostream &sout, const Array<T> &A){
	sout << "[ ";
	for (int i = 0; i < A.Size(); ++i)
		sout << A[i] << " ";
	sout << "]";
	return sout;
}

// insertion operator for Array<char>
ostream& operator<<(ostream &sout,const Array<char> &A) {
	for (int i = 0; i < A.Size(); ++i)
		sout << A[i];
	return sout;
}


#endif
