//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

//Computes average of a list of values
#include <iostream.h>

int main() {
	cout << "Please enter list of numbers" << endl;

	int ValuesProcessed = 0;
	float ValueSum = 0;
	float Value;

	while (cin >> Value) {
		ValueSum += Value;
		++ValuesProcessed;
	}

	if (ValuesProcessed > 0) {
		float Average = ValueSum / ValuesProcessed;
		cout << "Average: " << Average << endl;
	}
	else
		cout << "No list to average" << endl;

	return 0;
}



