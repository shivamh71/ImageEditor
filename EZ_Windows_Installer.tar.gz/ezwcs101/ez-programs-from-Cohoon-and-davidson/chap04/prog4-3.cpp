//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Sorts three numbers
#include <iostream.h>

int main() {
	// extract inputs and define outputs
	cout << "Please enter three numbers:";
	int Value1;
	int Value2;
	int Value3;
	cin >> Value1 >> Value2 >> Value3;
	int Output1;
	int Output2;
	int Output3;
	// determine which of the six orderings is applicable
	if ((Value1 <= Value2) && (Value2 <= Value3)) {
		// Value1 <= Value2 <= Value3
		Output1 = Value1;
		Output2 = Value2;
		Output3 = Value3;
	}
	else if ((Value1 <= Value3) && (Value3 <= Value2)) {
		// Value1 <= Value3 <= Value2
		Output1 = Value1;
		Output2 = Value3;
		Output3 = Value2;
	}
	else if ((Value2 <= Value1) && (Value1 <= Value3)) {
		// Value2 <= Value1 <= Value3
		Output1 = Value2;
		Output2 = Value1;
		Output3 = Value3;
	}
	else if ((Value2 <= Value3) && (Value3 <= Value1)) {
		// Value2 <= Value3 <= Value1
		Output1 = Value2;
		Output2 = Value3;
		Output3 = Value1;
	}
	else if ((Value3 <= Value1) && (Value1 <= Value2)) {
		// Value3 <= Value1 <= Value2
		Output1 = Value3;
		Output2 = Value1;
		Output3 = Value2;
	}
	else {// (Value3 <= Value2) && (Value2 <= Value1)
		// Value3 <= Value2 <= Value1
		Output1 = Value3;
		Output2 = Value2;
		Output3 = Value1;
	}
	// display results
	cout << Value1 << " " << Value2 << " " << Value3
	<< " in sorted order is " << Output1 << " "
	<< Output2 << " " << Output3 << endl;
	return 0;
}


