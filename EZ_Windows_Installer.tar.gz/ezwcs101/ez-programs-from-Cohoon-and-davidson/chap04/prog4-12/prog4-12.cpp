

// Simple visualization tool
#include <iostream.h>
#include "rect.h"

int ApiMain() {

	const float Unit = 0.25;
	cout << "Enter size of data set: ";
	int n;
	cin >> n;
	SimpleWindow W("Data set display", n+2, 10);
	W.Open();
	for (float x = 1; x <= n; ++x) {
		cout << "Enter data value (n): ";
		float y;
		cin >> y;
		RectangleShape Point(W, x, y, Blue, Unit, Unit);
		Point.Draw();
	}

	cout << "Type Ctrl-C to remove the display and exit" << endl;
	char AnyChar;
	cin >> AnyChar;
   W.Close();

   return 0;
}



