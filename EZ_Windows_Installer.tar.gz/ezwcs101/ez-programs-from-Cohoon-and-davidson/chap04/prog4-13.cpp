//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.1 $
// $Name: $
//
//**************************************************************************

// Display solutions for lazy hobo riddle
#include <iostream.h>

int main() {
	cout << "Lazy hobo possible solutions" << endl;
	for (int a = 1; a <= 14; a++) {
		for (int b = a; b <= 14; b++) {
			for (int c = b; c <= 14; c++) {
				for (int d = c; d <= 14; d++) {
					if (a*a + b*b + c*c + d*d == 200) {
						cout << a << " " << b << " " << c
						<< " " << d << endl;
					}
				}
			}
		}
	}
	return 0;
}



