//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Determine whether user date is valid
#include <iostream.h>

int main() {
	enum MonthsOfYear {January = 1, February = 2,
	March = 3, April = 4, May = 5, June = 6,
	July = 7, August = 8, September = 9,
	October = 10, November = 11, December = 12};
	// prompt and extract date
	cout << "Please supply a date (mm dd yyyy): ";
	int Month;
	int Day;
	int Year;
	cin >> Month >> Day >> Year;

	// compute days in February
	int DaysInFebruary;
	if ((Year % 4) != 0)
		DaysInFebruary = 28;
	else if ((Year % 400) == 0)
		DaysInFebruary = 29;
	else if ((Year % 100) == 0)
		DaysInFebruary = 28;
	else
		DaysInFebruary = 29;

	// if month is valid, determine how many days it has
	int DaysInMonth;
	switch (Month) {
		case January: case March: case May: case July:
		case August: case October: case December:
			DaysInMonth = 31;
			break;
		case April: case June: case September:
		case November:
			DaysInMonth = 30;
			break;
		case February:
			DaysInMonth = DaysInFebruary;
			break;
		default:
			cout << "Invalid month: " << Month << endl;
			return 1;
	}

	// determine whether input day is valid
	if ((Day < 1) || (Day > DaysInMonth)) {
		cout << "Invalid day of month: " << Day << endl;
		return 1;
	}

	// display result
	cout << Month << "/" << Day << "/" << Year
	<< " is a valid date" << endl;

	return 0;
}



