//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

//Compute average of five numbers
#include <iostream.h>

int main() {
	const int ListSize = 5;

	int ValuesProcessed = 0;										// no values processed yet
	float ValueSum = 0;										// no running total

	cout << "Please enter " << ListSize
	<< " numbers" << endl;

	while (ValuesProcessed < ListSize) {
		// there are more values to process
		float Value;
		cin >> Value;									// extract the next value
		ValueSum += Value;									// add value to running total
		++ValuesProcessed;									// increment number of values
											// that have been processed
	}

	float Average = ValueSum / ValuesProcessed;
	cout << "Average: " << Average << endl;

	return 0;
}



