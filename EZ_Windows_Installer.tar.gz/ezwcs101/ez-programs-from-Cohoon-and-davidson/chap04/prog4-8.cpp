//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

// Computes number of words and 
// number of articles 
#include <string>
#include <iostream.h>

int main() {
	// initialize counters for text analysis
	int NumberOfWords = 0;
	int NumberOfArticles = 0;
	// begin string processing
	string s;
	cout << "Enter text for analysis" << endl << endl;
	while (cin >> s) {
		// found another word
		++NumberOfWords;
		// test if the word an article
		if ((s == "the") || (s == "The") || ( s == "an")
		|| (s == "An") || (s == "a") || (s == "A")) {
			// the word an article
			++NumberOfArticles;
		}
	}
	// display test statistics
	cout << endl;
	cout << "Text contains " << NumberOfWords 
	<< " words of which " << NumberOfArticles
	<< " are articles" << endl;
	return 0;
}



