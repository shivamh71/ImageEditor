//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

// Echo input to standard output
// converting uppercase to lowercase along the way
#include <iostream.h>

int main() {
	// prepare for processing text
	bool MoreLinesToProcess = true;
	while (MoreLinesToProcess) {
		// process next line
		bool MoreCharactersOnCurrentLine = true;
		cout << "Please type a line of text: ";
		while (MoreCharactersOnCurrentLine) {
			// process next character on current line
			char CurrentCharacter;
			if (cin.get(CurrentCharacter)) {
				// process current character on current line
				if (CurrentCharacter == '\n') {
					// found new line character that ends line
					MoreCharactersOnCurrentLine = false;
				}
				else if ((CurrentCharacter >= 'A')
				&& (CurrentCharacter <= 'Z')) {
					// CurrentCharacter is uppercase
					CurrentCharacter = CurrentCharacter - 'A'
					+ 'a';
					cout << CurrentCharacter;
				}
				else { // nonuppercase character
					cout << CurrentCharacter;
				}
			}
			else { // no more characters
				MoreCharactersOnCurrentLine = false;
				MoreLinesToProcess = false;
			}
		}
		// finish processing of current line
		cout << endl;
	}
	// finish overall processing
	return 0;
}



