//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

//Compute a simple arithmetic expression
#include <iostream.h>

int main() {
	// prompt and extract desired operation
	cout << "Please enter a simple expression "
	 << "(number operator number): ";
	int LeftOperand;
	int RightOperand;
	char Operator;
	cin >> LeftOperand >> Operator >> RightOperand;

	// validate and compute desired operation
	int Result;
	switch (Operator) {
		case '+':
			Result = LeftOperand + RightOperand;
			break;
		case '-':
			Result = LeftOperand - RightOperand;
			break;
		case '*':
			Result = LeftOperand * RightOperand;
			break;
		case '/':
			if (RightOperand!= 0)
				Result = LeftOperand / RightOperand;
			else {
				cout << LeftOperand << " / "
				 << RightOperand << "cannot be computed:"
				 << " denominator is 0." << endl;
				return 1;
			}
			break;
		default:
			cout << Operator
			 << " is unrecognized operation." << endl;
			return 1;
	}

	// display result
	cout << LeftOperand << " " << Operator << " "
	<< RightOperand << " equals " << Result << endl;

	return 0;
}

