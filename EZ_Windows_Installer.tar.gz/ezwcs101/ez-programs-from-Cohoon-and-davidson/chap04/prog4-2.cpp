//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#include <iostream.h>

int main() {
	cout << "Please enter three numbers: ";
	int Value1;
	int Value2;
	int Value3;
	cin >> Value1 >> Value2 >> Value3;
	int Smallest;
	if (Value1 <= Value2) {
		// Value1 is at most Value2
		if (Value1 <= Value3) 
			// Value1 is also at most Value3
			Smallest = Value1;
		else // Value3 < Value1
			// Value3 is less than Value1, which is at most
			// Value2
			Smallest = Value3;
	}
	else { // Value2 < Value1
		// Value2 is less than Value1
		if (Value2 <= Value3)
			// Value2 is also at most Value3
			Smallest = Value2;
		else // Value3 < Value2
			// Value3 is less than Value2, which is at most
			// Value1
			Smallest = Value3;
	}
	cout << "The smallest of "
	<< Value1 << ", " << Value2 << ", and " << Value3
	<< " is " << Smallest << endl;

	return 0;
}

