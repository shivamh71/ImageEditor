//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: $
//
//**************************************************************************

// Convert a date from American format to
// international format
#include <string>
#include <iostream.h>

int main() {
   // Prompt for and read the date
   cout << "Enter the date in American format "
    << "(e.g., December 29, 1953) : ";
   string Date;
   getline(cin, Date, '\n');

   // Get the month by finding the first blank character
   int i = Date.find(' ');
   string Month = Date.substr(0, i);

   // Get the day by finding the comma character
   int k = Date.find(',');
   string Day = Date.substr(i + 1, k - i - 1);

   // Get the year by getting the substring from the blank
   // following the comma through the end of the string
   string Year = Date.substr(k + 2, Date.size() - k - 2);
   string NewDate = Day + " " + Month + " " + Year;

   cout << "Original date: " << Date << endl;
   cout << "Converted date: " << NewDate << endl;
   return 0;
}

