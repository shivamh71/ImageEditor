//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

// Program 3.4: Compute the time and cost required to mow
// a lawn
#include <string>
#include <iostream>
#include "rect.h"
using namespace std;

int ApiMain() {
	// Mowing rate in square meters per second
	const float MowRate = 1.0f;
	// Pay rate desired
	const float PayRate = 6.0f;

	// Seconds in an hour
	const int SecondsPerMinute = 60;
	// Minutes in an hour
	const int SecondsPerHour =
	 SecondsPerMinute * 60;

	// Length and width of display window
	const float DisplayLength = 20.0f;
	const float DisplayHeight = 20.0f;

	// Scale factor for display. 100 meters equals
	// 1 centimeter
	const float ScaleFactor = 0.01f;

	cout << "Please use meters for all input\n" << endl;

	long LawnLength; // Length of the lawn in meters
	cout << "Please enter the length of the lawn: ";
	cin >> LawnLength;

	long LawnWidth; // Width of the lawn in meters
	cout << "Please enter the width of the lawn: ";
	cin >> LawnWidth;

	long HouseLength; // Length of the house in meters
	cout << "Please enter the length of the house: ";
	cin >> HouseLength;

	long HouseWidth; // Width of the house in meters
	cout << "Please enter the width of the house: ";
	cin >> HouseWidth;

	// Echo the input so they can be verified
	cout << endl;
	cout << "Yard size: " << LawnLength << " by "
	 << LawnWidth << " meters" << endl;
	cout << "House size: " << HouseLength << " by "
	 << HouseWidth << " meters" << endl;

	// Compute the mowable area
	long MowableArea = (LawnLength * LawnWidth)
	 - (HouseLength * HouseWidth);

	// Compute the time to cut and display it
	long MowTimeInSeconds = MowableArea / MowRate;
	long Hours = MowTimeInSeconds / SecondsPerHour;
	long Minutes = (MowTimeInSeconds
	 - (Hours * SecondsPerHour)) / SecondsPerMinute;

	cout << "Time to cut: " << Hours << " hour(s) "
	 << Minutes << " minute(s)" << endl;
	// Compute the cost and display it
	float DollarCost = MowTimeInSeconds * PayRate
	 / SecondsPerHour;
	int Dollars = DollarCost;
	int Cents = (DollarCost - Dollars) * 100;
	cout << "Cost to cut: " << Dollars << " dollar(s)"
	 << " and " << Cents << " cent(s)" << endl;

	// Open the window and display the lawn
	SimpleWindow Display("Lawn and House Plot",
	 DisplayLength, DisplayHeight);
	Display.Open();

	RectangleShape Lawn(Display, DisplayLength / 2.0f,
	 DisplayHeight / 2.0f, Green,
	 LawnLength * ScaleFactor,
	 LawnWidth * ScaleFactor);
	 Lawn.Draw();
	// Display the house
	RectangleShape House(Display, DisplayLength / 2.0f,
	 DisplayHeight / 2.0f, Yellow,
	 HouseLength * ScaleFactor,
	 HouseWidth * ScaleFactor);
	House.Draw();

	cout << "Type Ctrl-C to remove the display and exit" << endl;
	char AnyChar;
	cin >> AnyChar;
	Display.Close();

	return 0;
}


