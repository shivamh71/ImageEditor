//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Program 3.1: Compute area and circumference
// of circle given radius
// Program modified to use const declaration
#include <iostream.h>


int main() {
	cout << "Circle radius (real number)? " << flush;
	float Radius;
	cin >> Radius;

	const float Pi = 3.1415f;
	cout << "Area of circle with radius " << Radius
	 << " is " << (Pi * Radius * Radius) << endl;
	cout << "Circumference is " << Pi * 2 * Radius
	 << endl;
	return 0;
}
