//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: $
//
//**************************************************************************

// Program 3.3: Compute estimated yearly savings
// by saving pocket change
#include <iostream.h>

int main() {
	cout << "For each week enter 4 numbers:\n"
	 " pennies nickels dimes quarters (e.g.: 3 2 4 1)\n"
	<< endl;

	// Prompt for and read the amount of change for
	// 4 weeks
	cout << "Week 1 change: " << flush;
	int Pennies, Nickels, Dimes, Quarters;
	cin >> Pennies >> Nickels >> Dimes >> Quarters;
	int TotalPennies = Pennies;
	int TotalNickels = Nickels;
	int TotalDimes = Dimes;

	int TotalQuarters = Quarters;

	cout << "Week 2 change: " << flush;
	cin >> Pennies >> Nickels >> Dimes >> Quarters;
	TotalPennies += Pennies;
	TotalNickels += Nickels;
	TotalDimes += Dimes;
	TotalQuarters += Quarters;

	cout << "Week 3 change: " << flush;
	cin >> Pennies >> Nickels >> Dimes >> Quarters;
	TotalPennies += Pennies;
	TotalNickels += Nickels;
	TotalDimes += Dimes;
	TotalQuarters += Quarters;

	cout << "Week 4 change: " << flush;
	cin >> Pennies >> Nickels >> Dimes >> Quarters;
	TotalPennies += Pennies;
	TotalNickels += Nickels;
	TotalDimes += Dimes;
	TotalQuarters += Quarters;

	cout << "Over four weeks you collected\n " <<
	TotalPennies << " Pennies\n " << TotalNickels
	<< " Nickels\n " << TotalDimes << " Dimes\n "
	<< TotalQuarters << " Quarters" << endl;
	// Compute and print total savings and the
	// weekly average
	int Total = TotalPennies + TotalNickels * 5
	+ TotalDimes * 10 + TotalQuarters * 25;
	int Average = Total / 4;
	int TotalDollars = Total / 100;
	int TotalCents = Total % 100;
	int AverageDollars = Average / 100;
	int AverageCents = Average % 100;
	cout << "which is " << TotalDollars << " dollar(s) and "
	 << TotalCents << " cent(s)." << endl;
   cout << "This is a weekly average of "
	<< AverageDollars << " dollar(s) and " << AverageCents
	<< " cent(s)." << endl;

	// Compute and print estimated yearly savings
	int YearSavings = Average * 52;
	int YearDollars = YearSavings / 100;
	int YearCents = YearSavings % 100;
	cout << "Estimated yearly savings: "
	 << YearDollars << " dollar(s) and "
    << YearCents << " cent(s)." << endl;
	return 0;
}


