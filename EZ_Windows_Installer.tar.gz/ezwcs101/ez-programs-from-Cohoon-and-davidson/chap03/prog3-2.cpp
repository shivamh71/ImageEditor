//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

// Compute number of molecules in a
// a hydrocarbon
#include <iostream.h>

int main() {
	cout << "Enter mass of hydrocarbon (in grams)\n"
	"followed by the number of carbon atoms\n"
	"followed by the number of hydrogen atoms\n"
	 "(e.g. 10.5 2 6): ";

	float Mass;
	int CarbonAtoms;
	int HydrogenAtoms;
	cin >> Mass >> CarbonAtoms >> HydrogenAtoms;

	const int CarbonAMU = 12;
	const int HydrogenAMU = 1;
	long FormulaWght = (CarbonAtoms * CarbonAMU)
	 + (HydrogenAtoms * HydrogenAMU);

	const double AvogadroNmbr = 6.02e23;
	double Molecules = (Mass / FormulaWght) *
	 AvogadroNmbr;
	cout << Mass << " grams of a hydrocarbon\nwith "
	 << CarbonAtoms << " carbon atom(s) and "
	 << HydrogenAtoms << " hydrogen atom(s)\ncontains "
	 << Molecules << " molecules" << endl;

	return 0;
}

