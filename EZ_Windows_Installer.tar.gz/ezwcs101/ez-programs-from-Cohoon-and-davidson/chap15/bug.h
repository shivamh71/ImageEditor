//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#ifndef BUG_H
#define BUG_H
#include "bitmap.h"
#include "randint.h"

// Miscellaneous prototypes
bool operator<(const BitMap &p, const BitMap &q);
bool operator==(const BitMap &p, const BitMap &q);

//
// class for a simple bug
//
enum Direction {Up, Down, Left, Right };
const int BugBitMaps = 4;  // One bitmap for each direction
class Bug {
	public:
		Bug(SimpleWindow &w, int HitsNeeded = 3,
		 int DirectionChangeProbability = 50);
		bool IsHit(const Position &MousePosition);
		bool IsDying();
		void Create();
		void Kill();
		virtual void Move() = 0;
	protected:
		// Bug inspectors
		SimpleWindow& GetWindow() const;
		Position GetPosition() const;
		Direction GetDirection() const;
		float GetHorizMovement() const;
		float GetVertMovement() const;
		int GetDirectionChangeProbability() const;
		BitMap& GetBmp(const Direction &d);
		const BitMap& GetBmp(const Direction &d) const;
		// Bug mutators
		void SetWindow(SimpleWindow &w);
		void SetDirection(const Direction &d);
		void SetHorizMovement(float h);
		void SetVertMovement(float v);
		void Draw();
		void Erase();
		void SetPosition(const Position &p);
		void ChangeDirection();
		Position NewPosition() const;
		bool AtRightEdge() const;
		bool AtLeftEdge() const;
		bool AtBottomEdge() const;
		bool AtTopEdge() const;
		RandomInt GeneratePercentage;
	private:
		// Data members
		SimpleWindow &Window;
		BitMap Bmp[BugBitMaps];
		float HorizMovement;
		float VertMovement;
		int HitsRequired;
		int HitsTaken;
		int DirectionChangeProbability;
		Direction CurrentDirection;
		Position CurrentPosition;
};

class SlowBug : public Bug {
	public:
		SlowBug(SimpleWindow &w, int HitsNeeded = 4,
		 int DirectionChange = 10);
		void Move();
};

class FastBug : public Bug {
	public:
		FastBug(SimpleWindow &w, int HitsNeeded = 3,
		 int DirectionChangeProbability = 20);
		void Move();
};

#endif
