//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#include "bughunt.h"

GameController *BugGame;

// TimerCallBack -- on a timer tick call BugGame's
// timer tick handler
int TimerCallBack(void) {
	BugGame->TimerTick();
	return 1;
}

// MouseCallBack -- on a mouse click call BugGame's
// mouse click handler
int MouseCallBack(const Position &MousePosition) {
	BugGame->MouseClick(MousePosition);
	return 1;
}

// ApiMain -- allocate the game controller, set up
// the call backs, and start the game
int ApiMain() {
	BugGame = new GameController();
	(BugGame->GetWindow())->SetTimerCallback(TimerCallBack);
	(BugGame->GetWindow())->SetMouseClickCallback(MouseCallBack);
	BugGame->Play(Slow);

	return 0;
}

// UserEnd -- destroy the game
int ApiEnd() {
	delete BugGame;

	return 0;
}








