//**************************************************************************//
//                                                                          //
// Copyright (c) 1997.                                                      //
//      Richard D. Irwin, Inc.                                              //
//                                                                          //
// This software may not be distributed further without permission from     //
// Richard D. Irwin, Inc.                                                   //
//                                                                          //
// This software is distributed WITHOUT ANY WARRANTY. No claims are made    //
// as to its functionality or purpose.                                      //
//                                                                          //
// Authors: James P. Cohoon and Jack W. Davidson                            //
// Date: 7/15/96                                                            //
// Version: $Revision: 1.2 $                                                      //
//                                                                          //
//**************************************************************************//

#ifndef BWINDOW_H
#define BWINDOW_H
#include "bug.h"

enum GameLevel { Slow, Fast, Done };
enum GameStatus {GameWon, Playing, GameLost, SettingUp };

// Speed of game (i.e. timer interval)
const int GameSpeed = 100;
// Types of bugs, this should match the number of
// game levels (Slow + Fast = 2)
const int NumberOfBugTypes = 2;

class GameController {
	public:
		GameController(const string &Title = "Bug Hunt!",
		 const Position &WinPosition = Position(3.0, 3.0),
		 const float WindLength = 14.0,
		 const float WinHeight = 10.0);
		~GameController();
		SimpleWindow *GetWindow();
		void Reset();
		void Play(const GameLevel Level);
		int MouseClick(const Position &MousePosition);
		int TimerTick();
	private:
		void BugHit();
		GameLevel CurrentLevel() const;
		Bug *CurrentBug() const;
		SimpleWindow *GameWindow;
		GameLevel Level;
		GameStatus Status;
		Bug* KindOfBug[NumberOfBugTypes];
};
#endif


