//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

#include <assert.h>
#include "bughunt.h"


GameController::GameController(const string &Title,
 const Position &WinPosition, const float WinLength,
 const float WinHeight) : Level(Slow),
 Status(SettingUp) {
	// Create a window and open it
	GameWindow = new SimpleWindow(Title,
	 WinLength, WinHeight, WinPosition);
	GetWindow()->Open();

	// Create the bugs.
	// Note this must be done AFTER the window is opened
	// because initialization of the bugs depends on having
	// a window.
	KindOfBug[Slow] = new SlowBug(*GetWindow());

	// Create a fast bug
	KindOfBug[Fast] = new FastBug(*GetWindow());
}

GameController::~GameController() {
	// Get rid of the bugs and the window
	delete KindOfBug[Slow];
	delete KindOfBug[Fast];
	delete GameWindow;
}

// GetWindow(): return the window containing the game
SimpleWindow *GameController::GetWindow() {
	return GameWindow;
}

// Reset(): reset the game at the beginning
void GameController::Reset() {
	Status = SettingUp;
	Level = Slow;
	CurrentBug()->Create();
}

// Play(): start playing the game at the designated level
void GameController::Play(const GameLevel l) {
	Level = l;
	Status = Playing;
	GetWindow()->StartTimer(GameSpeed);
}

// MouseClick() check to see if they hit the bug
// if so, update the status of the game
int GameController::MouseClick(const Position &MousePosition) {
	// Only pay attention to the mouse if game in progress
	if (Status == Playing
	 && CurrentBug()->IsHit(MousePosition)) {
		BugHit();
		// They won the game!
		// Let them know and start over
		if (Status == GameWon) {
			GetWindow()->StopTimer();
			GetWindow()->Message("You Won!");
			Reset();
			Play(Slow);
		}
	}
	else {
		// They missed the bug
		// Let them know and start over
		GetWindow()->StopTimer();
		GetWindow()->Message("You Missed!");
		CurrentBug()->Kill();
		Reset();
		Play(Slow);
	}
	return 1;
}

// TimerTick(): move the bug
int GameController::TimerTick() {
	CurrentBug()->Move();
	return 1;
}

// BugHit(): player hit the bug
void GameController::BugHit() {
	// Determine if bug is dying
	// If so, kill it and determine if the game is over
	// if not over advance to next level of play
	if (CurrentBug()->IsDying()) {
		CurrentBug()->Kill();
		Level  = (GameLevel) (Level + 1);
		if (Level == Done)
			Status = GameWon;
		else
			// Create the new faster bug
			CurrentBug()->Create();
	}
}

// CurrentLevel(): return the current level
GameLevel GameController::CurrentLevel() const {
	return Level;
}

// CurrentBug(): return a pointer to the current bug
Bug *GameController::CurrentBug() const {
	return KindOfBug[CurrentLevel()];
}

