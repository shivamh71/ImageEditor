//**************************************************************************//
//                                                                          //
// Copyright (c) 1997.                                                      //
//      Richard D. Irwin, Inc.                                              //
//                                                                          //
// This software may not be distributed further without permission from     //
// Richard D. Irwin, Inc.                                                   //
//                                                                          //
// This software is distributed WITHOUT ANY WARRANTY. No claims are made    //
// as to its functionality or purpose.                                      //
//                                                                          //
// Authors: James P. Cohoon and Jack W. Davidson                            //
// Date: 7/15/96                                                            //
// Version: 1.0b                                                            //
//                                                                          //
//**************************************************************************//

// Program 7.5: Validate a telephone access code
#include <iostream.h>
#include <ctype.h>
#include "bool.h"

// Prototypes for utility functions that main will use

bool Get(istream &in, int &d1, int &d2, int &d3,
int &d4, int &d5);
bool Valid(int d1, int d2, int d3, int d4, int d5);

int main() {
	int d1;
	int d2;
	int d3;
	int d4;
	int d5;

	if (Get(cin, d1, d2, d3, d4, d5) 
	 && Valid(d1, d2, d3, d4, d5))
		return 0;
	else
		return 1;
}

bool Get(istream &sin, int &d1, int &d2, int &d3,
int &d4, int &d5) {
	char c1;
	char c2;
	char c3;
	char c4;
	char c5;

	if (sin >> c1 >> c2 >> c3 >> c4 >> c5) {
		if (isdigit(c1) && isdigit(c2) && isdigit(c3)
				&& isdigit(c4) && isdigit(c5)) {
			d1 = c1 - '0';
			d2 = c2 - '0';
			d3 = c3 - '0';
			d4 = c4 - '0';
			d5 = c5 - '0';
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

bool Valid(int d1, int d2, int d3, int d4, int d5) {
	if (d4 == 0)
		return false;
	else
		return ((d1 + d2 + d3) % d4) == d5;
}


