//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Program to train a parts inspector
#include <iostream.h>
#include <assert.h>
#include "uniform.h"
#include "rect.h"

// Length of display window
const float DisplayLength = 14.0;
const float DisplayHeight = 6.0;

// Vertical position of squares
const float YPosition = DisplayHeight / 2.0;

// Length of the session (60 seconds)
const long TestTime = 60 * 1000L;

// Randomly pick one of the six colors
color GenerateRandomColor() {
	switch (Uniform(0, 5)) {
		case 0: return Red;
		case 1: return Blue;
		case 2: return Green;
		case 3: return Yellow;
		case 4: return Cyan;
		case 5: return Magenta;
	}
	// Shouldn't get here, but it keeps the compiler
	// from complaining
	return Red;
}

// Generate the test parts by randomly
// setting the color of the three parts
void GetPartsImages(RectangleShape &P1,
 RectangleShape &P2, RectangleShape &P3) {

	P1.SetColor(GenerateRandomColor());
	P2.SetColor(GenerateRandomColor());
	P3.SetColor(GenerateRandomColor());

	return;
}

// Display the shapes
void DisplayPartsImages(RectangleShape &P1,
 RectangleShape &P2, RectangleShape &P3) {

	P1.Draw();
	P2.Draw();
	P3.Draw();

	return;
}

// Print the results from the training session
void PrintSessionResults(long Time, int Attempts,
 int Correct, int Wrong) {

	cout << "\n\nFor a training period of "
	 << Time / 1000L << " seconds" << endl;
	cout << "Groups viewed: " << Attempts << endl;
	cout << "Correct responses: " << Correct << endl;
	cout << "Incorrect responses: " << Wrong << endl;
	cout << "Percent correct: "
	 << (Correct / (float) Attempts * 100) << endl;

	return;
}

// Determine if the appropriate response was given
int CheckResponse(char Response,
 const RectangleShape &P1, const RectangleShape &P2,
 const RectangleShape &P3) {

	if (P1.GetColor() == P2.GetColor()
	 || P1.GetColor() == P3.GetColor()
	 || P2.GetColor() == P3.GetColor())
		return Response == 'a';
	else
		return Response == 'r';
}

int ApiMain() {

	InitializeSeed();
	// Window for displaying the objects
	SimpleWindow DisplayWindow("Training Window",
	 DisplayLength, DisplayHeight);
	DisplayWindow.Open();
	assert(DisplayWindow.GetStatus() == WindowOpen);

	// Print message telling user to arrange windows
	cout << "Please resize this window so that\n"
	 << "that both windows are visible,\n"
	 << "and they do not overlap.\n"
	 << "Type any character followed by a return\n"
	 << "when you are ready to proceed" << endl;
	char Response;
	cin >> Response;

	cout << "\n\n\n" << flush;


	// Create three rectangles for the three parts
	RectangleShape Part1(DisplayWindow,
	 3.0, YPosition, Blue, 2.0, 2.0);
	RectangleShape Part2(DisplayWindow,
	 7.0, YPosition, Blue, 2.0, 2.0);
	RectangleShape Part3(DisplayWindow,
	 11.0, YPosition, Blue, 2.0, 2.0);

	// Define objects for scoring the trainee
	int Attempts = 0;   // Number of tests done
	int CorrectResponses = 0;
	int IncorrectResponses = 0;

	// Begin the training session

	// Record starting time
	const long StartTime = GetMilliseconds();
	long ElapsedTime;
	do {
		GetPartsImages(Part1, Part2, Part3);
		DisplayPartsImages(Part1, Part2, Part3);

		cout << "Accept or reject (a or r)? " << flush;
		char Response;
		cin >> Response;

		++Attempts;
		if (CheckResponse(Response, Part1, Part2, Part3))
			++CorrectResponses;
		else
			++IncorrectResponses;
		ElapsedTime = GetMilliseconds();
	} while ((ElapsedTime - StartTime) < TestTime);

	PrintSessionResults(TestTime, Attempts,
	 CorrectResponses, IncorrectResponses);

	return 0;
}





