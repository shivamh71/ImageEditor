//**************************************************************************//
//                                                                          //
// Copyright (c) 1997.                                                      //
//      Richard D. Irwin, Inc.                                              //
//                                                                          //
// This software may not be distributed further without permission from     //
// Richard D. Irwin, Inc.                                                   //
//                                                                          //
// This software is distributed WITHOUT ANY WARRANTY. No claims are made    //
// as to its functionality or purpose.                                      //
//                                                                          //
// Authors: James P. Cohoon and Jack W. Davidson                            //
// Date: 7/15/96                                                            //
// Version: 1.0b                                                            //
//                                                                          //
//**************************************************************************//

// Program 7.3: Input three numbers and output them
// in sorted order
#include <iostream.h>
// Swap(): swap two values
void Swap(int &x, int &y) {
	int tmp = x;
	x = y;
	y = tmp;
	return;
}

// Sort3(): sort three numbers into non-descending order
void Sort3(int &a, int &b, int &c) {
	if (a > b)
		Swap(a, b);
	if (a > c)
		Swap(a, c);
	if (b > c)
		Swap(b, c);
	return;
}

// read three numbers and output them in sorted order
int main() {
	cout << "Please enter three integers: " << flush;
	int Input1;
	int Input2;
	int Input3;
	cin >> Input1 >> Input2 >> Input3;
	int Output1 = Input1;
	int Output2 = Input2;
	int Output3 = Input3;

	// Sort the three numbers
	Sort3(Output1, Output2, Output3);

	// Output the sorted numbers
	cout << Input1 << " " << Input2 << " " << Input3
	<< " in sorted order is "
	<< Output1 << " " << Output2 << " " << Output3
	<< endl;

	return 0;
}
