//**************************************************************************//
//                                                                          //
// Copyright (c) 1997.                                                      //
//      Richard D. Irwin, Inc.                                              //
//                                                                          //
// This software may not be distributed further without permission from     //
// Richard D. Irwin, Inc.                                                   //
//                                                                          //
// This software is distributed WITHOUT ANY WARRANTY. No claims are made    //
// as to its functionality or purpose.                                      //
//                                                                          //
// Authors: James P. Cohoon and Jack W. Davidson                            //
// Date: 7/15/96                                                            //
// Version: 1.0b                                                            //
//                                                                          //
//**************************************************************************//

// Program 7.4: Sorting numbers read from a file
#include <iostream.h>
#include <fstream.h>
#include "bool.h"
// ReadValues(): read three values
// if from cin, then prompt user
bool ReadValues(istream &in, int &v1, int &v2,
int &v3) {
	if (in == cin)
		cout << "Please enter three numbers" << flush;
	if (in >> v1 >> v2 >> v3)
		return true;
	else
		return false;
}

// Swap(): swap two values
void Swap(int &x, int &y) {
	int tmp = x;
	x = y;
	y = tmp;
	return;
}

// Sort3(): sort three numbers into non-descending order
void Sort3(int &a, int &b, int &c) {
	if (a > b)
		Swap(a, b);
	if (a > c)
		Swap(a, c);
	if (b > c)
		Swap(b, c);
	return;
}

int main() {

	// Open the input file
	ifstream fin("test.dat");
	if (!fin) {
		cerr << "Could not open test.dat" << endl;
		return 1;
	}
	int Input1;
	int Input2;
	int Input3;
	if (!ReadValues(fin, Input1, Input2, Input3)) {
		cerr << "Could not read three values" << endl;
		return 1;
	}
	int Output1 = Input1;
	int Output2 = Input2;
	int Output3 = Input3;

	// Sort the three numbers
	Sort3(Output1, Output2, Output3);

	// Output the sorted numbers
	cout << Input1 << " " << Input2 << " " << Input3
	<< " in sorted order is "
	<< Output1 << " " << Output2 << " " << Output3
	<< endl;
	return 0;
}
