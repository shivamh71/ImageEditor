//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#ifndef ELEMENT_H
#define ELEMENT_H

class Element {
	public:
		// default constructor
		Element(int x = 0, int y = 0, int z = 0);
		// inspectors
		int GetX() const;
		int GetY() const;
		int GetZ() const;
		// mutators
		void SetX(int x);
		void SetY(int y);
		void SetZ(int z);
	private:
		// data members
		int X;
		int Y;
		int Z;
};

#endif
