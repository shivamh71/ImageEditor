//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#ifndef GUESS_H
#define GUESS_H

#include <iostream.h>
#include "element.h"

class Guess {
	public:
		// default constructor
		Guess();
		// inspector
		int GetDigit(int i) const;
		// mutator
		bool Update();
	protected:
		// mutator
		void SetDigit(int i, int v);
	private:
		Element Number;
};

// auxiliary operators
ostream& operator<<(ostream &sout, const Guess &G);

#endif
