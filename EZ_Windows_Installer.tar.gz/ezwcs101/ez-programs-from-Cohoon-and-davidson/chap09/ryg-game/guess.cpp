//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#include <iostream.h>
#include <stdlib.h>
#include "guess.h"

// Guess(): default constructor
Guess::Guess() {
	Number.SetX(0);
	Number.SetY(0);
	Number.SetZ(0);
}

// GetDigit(): get aspect of guess
int Guess::GetDigit(int i) const {
	int DigitValue;
	switch (i) {
		case 1: DigitValue = Number.GetX(); break;
		case 2: DigitValue = Number.GetY(); break;
		case 3: DigitValue = Number.GetZ(); break;
		default:
			cerr << "Bad digit request: " << i << endl;
			exit(1);
	}
	return DigitValue;
}
// SetDigit(): Set aspect of guess
void Guess::SetDigit(int i, int v) {
	switch (i) {
		case 1: Number.SetX(v); break;
		case 2: Number.SetY(v); break;
		case 3: Number.SetZ(v); break;
		default:
			cerr << "Bad digit request: " << i << endl;
			exit(1);
	}
}
// Update(): acquire new guess from player
bool Guess::Update() {
	int Value;
	if (cin >> Value) {
		if ((Value >= 100) && (Value <= 999)) {
			int d1 = Value / 100;
			int d2 = (Value - (d1 * 100)) / 10;
			int d3 = Value % 10;
			SetDigit(1, d1);
			SetDigit(2, d2);
			SetDigit(3, d3);
		}
		else
			cerr << "Illegal guess ignored." << endl;
		return true;
	}
	else
		return false; 
}


// operator <<: insert a guess
ostream& operator<<(ostream &sout, const Guess &G) {
	sout << G.GetDigit(1) << G.GetDigit(2) << G.GetDigit(3);
	return sout;
}


