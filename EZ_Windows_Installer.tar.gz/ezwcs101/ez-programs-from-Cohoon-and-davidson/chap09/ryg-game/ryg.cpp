//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#include <iostream.h>
#include <stdlib.h>
#include "randint.h"
#include "rect.h"
#include "label.h"
#include "ryg.h"

SimpleWindow wout("Red-yellow-green", 10, 4);

// default RYG constructor
RYG::RYG() {
	wout.Open();
	EzRandomize();
	RandomInt x(1, 9);
	RandomInt y(0, 9);
	RandomInt z(0, 9);
	SecretNumber.SetX(x.Draw());
	SecretNumber.SetY(y.Draw());
	SecretNumber.SetZ(z.Draw());
}

// Welcome(): display opening message
void RYG::Welcome() const {
	cout << "Welcome to the red-yellow-green game.\n"
	 << "A number between 100 and 999 has been chosen\n"
	 << "for you to guess.\n" << endl;
}

// Prompt(): request next guess
void RYG::Prompt() const {
	cout << "What is your guess? ";
}

// Congratulations(): announce their success
void RYG::Congratulations() const {
	Display(UserInput, UserFeedback);
	cout << "Congratulations on your win!" << endl;
}

// GoodBye(): tell player so long
void RYG::GoodBye() const {
	cout << "Better luck next time" << endl;
}

void RYG::Play() {
	Welcome();
	Prompt();
	while (UserInput.Update()) {
		UserFeedback = Evaluate(UserInput);
		Display(UserInput, UserFeedback);
		if (Winner(UserFeedback)) {
			Congratulations();
			return;
		}
		else {
			Prompt();
		}
	}
	GoodBye();
}


// Winner(): reports whether response is all greens
bool RYG::Winner(const Response &R) const {
	return R.GetGreen() == 3;
}

// Display(): announce reds, yellows, greens
void RYG::Display(const Guess &G, const Response &R) const {
	int rcount = R.GetRed();
	int ycount = R.GetYellow();
	int gcount = R.GetGreen();
	// display textual response
	cout << "Guess " << G << " corresponds to ";
	cout << rcount << " red, " << ycount << "yellow, and "
	 << gcount << " green " << "\n" << endl;
	// display graphical response
	float cx = 2;
	float cy = 2;
	for (int r = 0; r < rcount; ++r) {
		RectangleShape Box(wout, cx, cy, Red, 2, 2);
		Box.Draw();
		Label S(wout, cx, cy, "Red");
		S.Draw();
		cx += 3;
	}
	for (int y = 0; y < ycount; ++y) {
		RectangleShape Box(wout, cx, cy, Yellow, 2, 2);
		Box.Draw();
		Label S(wout, cx, cy, "Yellow");
		S.Draw();
		cx += 3;
	}
	for (int g = 0; g < gcount; ++g) {
		RectangleShape Box(wout, cx, cy, Green, 2, 2);
		Box.Draw();
		Label S(wout, cx, cy, "Green");
		S.Draw();
		cx += 3;
	}
}


// GetGreen(): return number of green responses to guess
int RYG::GetGreen(const Guess &G) const {
	int green = 0;
	if (G.GetDigit(1) == SecretNumber.GetX())
		++green;
	if (G.GetDigit(2) == SecretNumber.GetY())
		++green;
	if (G.GetDigit(3) == SecretNumber.GetZ())
		++green;
	return green;
}

// GetRed(): return number of red responses to guess
int RYG::GetRed(const Guess &G) const {
	int sx = SecretNumber.GetX();
	int sy = SecretNumber.GetY();
	int sz = SecretNumber.GetZ();
	int gx = G.GetDigit(1);
	int gy = G.GetDigit(2);
	int gz = G.GetDigit(3);

	int red = 0;
	if ((gx != sx) && (gx != sy) && (gx != sz))
		++red;
	if ((gy != sx) && (gy != sy) && (gy != sz))
		++red;
	if ((gz != sx) && (gz != sy) && (gz != sz))
		++red;
	return red;
}

// GetYellow(): return number of yellow responses to
// guess
int RYG::GetYellow(const Guess &G) const {
	return 3 - GetGreen(G) - GetRed(G);
}

// Evaluate(): determine reds, yellows, and greens
Response RYG::Evaluate(const Guess &G) const {
	return Response(GetRed(G), GetYellow(G),
	GetGreen(G));
}



