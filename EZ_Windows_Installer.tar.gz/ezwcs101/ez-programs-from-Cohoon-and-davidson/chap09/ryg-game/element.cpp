//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include "element.h"

// Element(): constructor
Element::Element(int x, int y, int z) {
	SetX(x);
	SetY(y);
	SetZ(z);
}

// GetX(): return X attribute
int Element::GetX() const {
	return X;
}

// GetY(): return Y attribute
int Element::GetY() const {
	return Y;
}

// GetZ(): return Z attribute
int Element::GetZ() const {
	return Z;
}

// SetX(): set X attribute
void Element::SetX(int x) {
	X = x;
}

// SetY(): set Y attribute
void Element::SetY(int y) {
	Y = y;
}

// SetZ(): set Z attribute
void Element::SetZ(int z) {
	Z = z;
}
