//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#ifndef RESPONSE_H
#define RESPONSE_H

#include "element.h"

class Response {
	public:
		// constructor
		Response(int r = 0, int y = 0, int g = 0);
		// inspectors
		int GetRed() const;
		int GetYellow() const;
		int GetGreen() const;
	protected:
		// mutators
		void SetRed(int r);
		void SetYellow(int y);
		void SetGreen(int g);
	private:
		Element Counts;
};

#endif;

