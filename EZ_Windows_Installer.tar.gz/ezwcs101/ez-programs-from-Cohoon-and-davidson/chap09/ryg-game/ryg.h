//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#ifndef RYG_H
#define RYG_H

#include "guess.h"
#include "response.h"
#include "element.h"

class RYG {
	public:
		// default constructor
		RYG();
		// facilitator
		void Play();
	protected:
		// facilitators
		void Welcome() const;
		void Prompt() const;
		Response Evaluate(const Guess &G) const;
		bool Winner(const Response &R) const;
		void Congratulations() const;
		void Display(const Guess &G, const Response &R)
		const;
		void GoodBye() const;
		int GetRed(const Guess &G) const;
		int GetYellow(const Guess &G) const;
		int GetGreen(const Guess &G) const;
	private:
		// data members
		Element SecretNumber;
		Guess UserInput;
		Response UserFeedback;
};
#endif
