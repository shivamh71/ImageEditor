//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Demonstrate Rational ADT
#include <iostream.h>
#include "rational.h"

int main() {
	Rational r;
	Rational s;
	cout << "Enter rational number (a/b): ";
	cin >> r;
	cout << "Enter rational number (a/b): ";
	cin >> s;

	Rational t(r);
	Rational Sum = r + s;
	Rational Product = r * s;

	cout << r << " + " << s << " = " << Sum << endl;
	cout << r << " * " << s << " = " << Product << endl;

	return 0;
}
