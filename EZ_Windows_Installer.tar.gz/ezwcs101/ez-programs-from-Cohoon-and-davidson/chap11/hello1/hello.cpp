//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

// Hello EzWindows program
#include <assert.h>
#include "ezwin.h"

// Create a 10 x 4 window
SimpleWindow HelloWindow("Hello EzWindows", 10.0, 4.0,
 Position(5.0, 6.0));

// ApiMain(): create a window and display greeting
int ApiMain() {
	HelloWindow.Open();
	assert(HelloWindow.GetStatus() == WindowOpen);

	// Get Center of Window
	Position Center = HelloWindow.GetCenter();

	// Create bounding box for text
	Position UpperLeft = Center + Position(-1.0, -1.0);
	Position LowerRight = Center + Position(1.0,  1.0);

	// Display the text
	HelloWindow.RenderText(UpperLeft, LowerRight,
	 "Hello EzWindows", Black);

	return 0;
}

// ApiEnd(): shutdown the window
int ApiEnd() {
	HelloWindow.Close();

	return 0;
}



