//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

#include <iostream>
#include <string>  // some compilers use <string> instead of cstring
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "randint.h"
#include "simon.h"

using namespace std;

SimonGame::SimonGame(SimpleWindow &Window) : W(Window) {
   // No body needed
}

// Initialize -- initialize the game, init'ing simon game objects
void SimonGame::Initialize() {
	int p;
	float X, Y;

	assert(W.GetStatus() == WindowOpen);
	SequenceLength = BeginningSequenceLength;

	X = InitialPosition.GetXDistance();
	Y = InitialPosition.GetYDistance();

   // BitMapFile holds the file names containing the bitmaps
	vector<string> BitMapFile(MaxPositions);
   BitMapFile[0] = "c1.bmp";
   BitMapFile[1] = "c2.bmp";
   BitMapFile[2] = "c3.bmp";
   BitMapFile[3] = "c4.bmp";

	for (p = 0; p < MaxPositions; ++p) {
		Posn[p].Initialize(W, BitMapFile[p],
		"cardbk1.bmp", Position(X, Y));
		Posn[p].Draw();
		X += Posn[p].GetWidth() + 0.5;
	}

	// Set up the control buttons
	Restart.SetWindow(W);
	Restart.Load("rbutton2.bmp");
	assert(Restart.GetStatus() == BitMapOkay);
	X = InitialPosition.GetXDistance();
	Y += Posn[0].GetHeight() + 2.0;
	Restart.SetPosition(Position(X, Y));
	Quit.SetWindow(W);
	Quit.Load("qbutton2.bmp");
	assert(Quit.GetStatus() == BitMapOkay);
	X = Restart.GetWidth() + 2.0;
	Quit.SetPosition(Position(X, Y));

	Restart.Draw();
	Quit.Draw();
}

// Play -- go play the simon game at the current level
void SimonGame::Play() {
	// it's simon's turn to flash the objects in order
	WhoseTurn = Simon;

	// turn all objects over ready for flashing
	for (int p = 0; p < MaxPositions; ++p) {
		Posn[p].SetSide(Back);
		Posn[p].Draw();
	}

	// pick a random order to flash the simon objects
	PickOrder();
	// Selection keeps track of the number of
	// objects flashed so far
	Selection = 0;

	// Start the timer for flashing the SimonObjects
	W.StartTimer(FlashInterval);
}


// Refresh -- redraw the display

int SimonGame::Refresh() {
	for (int p = 0; p < MaxPositions; ++p)
		Posn[p].Draw();

	Quit.Draw();
	Restart.Draw();

  return 1;
}

// MouseClick -- the main game driver
int SimonGame::MouseClick(const Position &MousePosn) {
	int p;

	// restart button clicked?
	if (Restart.IsInside(MousePosn)) {
		SequenceLength = BeginningSequenceLength;
		Play();
		return 1;
	}
  // quit button clicked?
	else if (Quit.IsInside(MousePosn))
		Terminate();

	// player's turn
	else if (WhoseTurn == Player) {
		// see if object selected
		if ((p = Find(MousePosn)) >= 0) {
			// flip the object over to show it
			Posn[p].SetSide(Front);
			Posn[p].Draw();
			// check whether the object was selected in
			// the right order
			if (p != Order[Selection]) {
				WhoseTurn = Simon;
				W.Message("Wrong Order!");
			}
			// check for successful selection of the
			// entire sequence
			else if (Selection + 1 == SequenceLength) {
				// reached highest level -- game over
				if (SequenceLength == MaxSequenceLength) {
					WhoseTurn = Simon;
					W.Message("You Win!!!");
				}
				// go to the next level
				else {
					++SequenceLength;
					Play();
				}
			}
			// next user selection in the order
			else
				++Selection;
		}
	}
	return 1;
}

// Timer -- process timer expiration events, flashing
//          simon objects
int SimonGame::Timer() {
	// see if we are done flashing objects
	if (Selection == SequenceLength) {
		WhoseTurn = Player;
		W.StopTimer();
		Selection = 0;
		return 1;
	}

	// Get the current object
	int p = Order[Selection];

	// flip object to back side, if not on that side
	// if on that side, flip it to front and
	// go to next object
	if (Posn[p].GetSide() == Back)
		Posn[p].Flip();
	else {
		Posn[p].Flip();
		++Selection;
	}
  return 1;
}

// Find -- find the selected simon object
int SimonGame::Find(const Position &MousePosn) const {
	for (int p = 0; p < MaxPositions; p++)
		if (Posn[p].IsInside(MousePosn))
			return p;

  return -1;
};

// PickOrder -- generate a random sequence
void SimonGame::PickOrder() {

	int i;

	for (i = 0; i < SequenceLength; ++i)
		Order[i] = i % MaxPositions;

	RandomInt R(0, SequenceLength - 1);
	for (i = 0; i < SequenceLength; ++i) {
		int j = R.Draw();
		int tmp = Order[j];
		Order[j] = Order[i];
		Order[i] = tmp;
	}
}
