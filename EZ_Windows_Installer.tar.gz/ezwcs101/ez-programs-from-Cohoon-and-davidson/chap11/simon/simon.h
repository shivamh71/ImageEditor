//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

#ifndef SIMON_H
#define SIMON_H

#include <vector>
#include "simobj.h"
using namespace std;

// Miscellaneous prototypes
bool operator<(const SimonObject &p, const SimonObject &q);
bool operator==(const SimonObject &p, const SimonObject &q);

const int MaxPositions = 4;
const int BeginningSequenceLength = 3;
const int MaxSequenceLength = 6;

// Lower this to make the game harder
const int FlashInterval = 800;

// Position of first SimonObject
const Position InitialPosition(1.0, 1.0);

class SimonGame {
	enum Turn { Simon, Player };
	public:
		SimonGame(SimpleWindow &Window);
		void Initialize();
		void Play();
		int Refresh();
		int MouseClick(const Position &MousePosn);
		int Timer();
		int Find(const Position &MousePosn) const;
		void PickOrder();
	private:
		SimpleWindow &W;
		SimonObject Posn[MaxPositions];
		BitMap Restart;
      BitMap Quit;
		int Order[MaxSequenceLength];
		int SequenceLength;
		Turn WhoseTurn;
		int Selection;
};
#endif
