//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "simobj.h"

using namespace std;

SimonObject::SimonObject() {
};

// Initialize -- load a card face and back for this
//               simon object
void SimonObject::Initialize(SimpleWindow &GameWindow,
 const string &FrontFile, const string &BackFile,
 const Position &Posn) {

	FrontSide.SetWindow(GameWindow);
	FrontSide.SetPosition(Posn);
	FrontSide.Load(FrontFile);
	assert(FrontSide.GetStatus() == BitMapOkay);

	BackSide.SetWindow(GameWindow);
	BackSide.SetPosition(Posn);
	BackSide.Load(BackFile);
	assert(BackSide.GetStatus() == BitMapOkay);
	SetSide(Back);
}

// SetSide -- set the current object's side
void SimonObject::SetSide(const Side &s) {
	SideShowing = s;
}

// GetSide -- get the current object's side
Side SimonObject::GetSide() const {
	return SideShowing;
}

// GetHeight -- get the height of the bitmap
float SimonObject::GetHeight() const {
	return FrontSide.GetHeight();
}

// GetWidth -- get the width of the bitmap
float SimonObject::GetWidth() const {
	return FrontSide.GetWidth();
}

// Flip -- flip the object and redraw it
void SimonObject::Flip() {
	SetSide(GetSide() == Back ? Front : Back);
	Draw();
}

// IsInside -- determine if a mouse click falls in
//             this object
bool SimonObject::IsInside(const Position &p) const {
	return BackSide.IsInside(p);
}

// Draw -- draw the object to the window
void SimonObject::Draw() {
	if (SideShowing == Back)
		BackSide.Draw();
	else
		FrontSide.Draw();
}

