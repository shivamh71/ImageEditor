//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

#include <iostream>
#include <string>
#include <assert.h>
#include <stdio.h>
#include "randint.h"
#include "simon.h"

using namespace std;

SimpleWindow GameWindow("Simon Game",
 12.5, 8.0, Position(0.25, 0.25));
SimonGame Simon(GameWindow);

// RefreshEvent -- pass window refresh to the game
int RefreshEvent() {
	return Simon.Refresh();
}

// MouseClickEvent -- pass mouse events to player
int MouseClickEvent(const Position &MousePosn) {
	return Simon.MouseClick(MousePosn);
}

// TimerEvent -- pass timer expirations to the game to check for card matches
int TimerEvent() {
	return Simon.Timer();
}

// ApiMain(): open the game window, set callbacks,
// and begin play.
int ApiMain() {
   EzRandomize();
	GameWindow.Open();
	GameWindow.SetMouseClickCallback(MouseClickEvent);
	GameWindow.SetRefreshCallback(RefreshEvent);
	GameWindow.SetTimerCallback(TimerEvent);
	Simon.Initialize();
   return 0;
}

int ApiEnd() {
	return 0;
}
