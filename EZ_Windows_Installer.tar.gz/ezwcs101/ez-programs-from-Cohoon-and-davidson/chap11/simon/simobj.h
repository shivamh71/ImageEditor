//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

#ifndef SIMONOBJECT_H
#define SIMONOBJECT_H
#include <string>    // some compilers use <string> instead of cstring
#include "bitmap.h"

using namespace std;

enum Side { Front, Back };
class SimonObject {
	public:
		SimonObject();
		void Initialize(SimpleWindow &GameWindow,
		 const string &FrontFile, const string &BackFile,
		 const Position &Posn);
		void SetSide(const Side &s);
		Side GetSide() const;
		float GetHeight() const;
      float GetWidth() const;
		void Draw();
		void Flip();
		bool IsInside(const Position &MousePosition) const;
	private:
		BitMap FrontSide;
		BitMap BackSide;
		Side SideShowing;
};
#endif
