//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: P2 P1 $
//
//**************************************************************************

//
// Display a bit map image in the
// center of a window

#include "bitmap.h"
#include <assert.h>

// Open a window to display the logo
SimpleWindow PhotoWindow("The Authors", 10.0, 7.0,
 Position(5.0, 3.0));

int ApiMain() {

	PhotoWindow.Open();
	assert(PhotoWindow.GetStatus() == WindowOpen);

	Position WindowCenter = PhotoWindow.GetCenter();

	// Create a bitmap
	BitMap Photo(PhotoWindow);

	// Load the image
	Photo.Load("picture.bmp");
	assert(Photo.GetStatus() == BitMapOkay);

	// Compute position of photo so it is centered
	// vertically in the window to the right
	Position PhotoPosition = WindowCenter +
	 Position(-.5 * Photo.GetWidth(),
	 -.5 * Photo.GetHeight());

	Photo.SetPosition(PhotoPosition);
	Photo.Draw();
	return 0;
}

int ApiEnd() {
	PhotoWindow.Close();
	return 0;
}

