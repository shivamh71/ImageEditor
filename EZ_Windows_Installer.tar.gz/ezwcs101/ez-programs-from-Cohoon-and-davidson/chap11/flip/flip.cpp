//**************************************************************************//
//                                                                          //
// Copyright (c) 1997.                                                      //
//      Richard D. Irwin, Inc.                                              //
//                                                                          //
// This software may not be distributed further without permission from     //
// Richard D. Irwin, Inc.                                                   //
//                                                                          //
// This software is distributed WITHOUT ANY WARRANTY. No claims are made    //
// as to its functionality or purpose.                                      //
//                                                                          //
// Authors: James P. Cohoon and Jack W. Davidson                            //
// Date: 7/15/96                                                            //
// Version: 1.0b                                                            //
//                                                                          //
//**************************************************************************//

// Demonstrate selecting an action
// by clicking in a bitmap

#include <assert.h>
#include "bitmap.h"

// Define a window
SimpleWindow FlipWindow("FlipCard", 15.0, 9.0,
 Position(1.0, 1.0));

// Define bitmaps for the front and back of a card
BitMap CardFront(FlipWindow);
BitMap CardBack(FlipWindow);

// Need a type and object for remembering which side
// of the card is showing
enum Side { Front, Back };
Side SideShowing;

// MouseClickEvent(): come here when user clicks mouse
int MouseClickEvent(const Position &MousePosition) {
	if (CardFront.IsInside(MousePosition)) {
		// card is selected so flip it
		if (SideShowing == Back) {
			SideShowing = Front;
			CardFront.Draw();
		}
		else if (SideShowing == Front) {
			SideShowing = Back;
			CardBack.Draw();
		}
	}

	return 1;
}

int ApiMain() {
	// Open the window
	FlipWindow.Open();
	assert(FlipWindow.GetStatus() == WindowOpen);

	// Load the images
	CardFront.Load("c1.bmp");
	assert(CardFront.GetStatus() == BitMapOkay);

	CardBack.Load("cardbk1.bmp");
	assert(CardBack.GetStatus() == BitMapOkay);

	// Compute position to display the card
	Position CardPosition = FlipWindow.GetCenter() +
	 Position(-.5 * CardFront.GetWidth(),
	 -.5 * CardFront.GetHeight());

	CardFront.SetPosition(CardPosition);
	CardBack.SetPosition(CardPosition);

	SideShowing = Front;
	CardFront.Draw();

	// Set up mouse call back
	FlipWindow.SetMouseClickCallback(MouseClickEvent);

	return 0;
}

int ApiEnd() {
	FlipWindow.Close();

	return 0;
}


