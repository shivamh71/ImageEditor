//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

// Example showing use of timer events
// The program displays a bitmap in the window at
// a random location when the timer goes off

#include <assert.h>
#include "bitmap.h"
#include "randint.h"

// Define two non-overlapping windows
SimpleWindow W1("Window One", 15.0, 9.0,
 Position(1.0, 1.0));

SimpleWindow W2("Window Two", 15.0, 9.0,
 Position(8.0, 12.0));

// Define two bitmaps, one for each window
BitMap W1Bmp(W1);
BitMap W2Bmp(W2);

// Redisplay(): move bitmap to a new location
void Redisplay(SimpleWindow &W, BitMap &B) {
	// Erase the bitmap
	B.Erase();

	// Compute a new position and display the bitmap
	// Make sure the bitmap is completely in the window

	// Initialize random number generator. Then create a
	// random number generator for the X position
	EzRandomize();
	RandomInt X(1, (int) W.GetWidth());
	int XCoord = X.Draw();
	if (XCoord + B.GetWidth() > W.GetWidth())
		XCoord = XCoord - (int) B.GetWidth();

	// Create RandomInt object the Y position
	RandomInt Y(1, (int) W.GetHeight());
	int YCoord = Y.Draw();
	if (YCoord + B.GetHeight() > W.GetHeight())
		YCoord = YCoord - (int) B.GetHeight();
	B.SetPosition(Position(XCoord, YCoord));
	B.Draw();
}

// W1TimerEvent(): call-back function for Window one
int W1TimerEvent() {
	Redisplay(W1, W1Bmp);

	return 1;
}

// W2TimerEvent(): call back function for Window two
int W2TimerEvent() {
	Redisplay(W2, W2Bmp);

	return 1;
}
// ApiMain(): open the windows and start the timers
int ApiMain() {
	// Open the windows
	W1.Open();
	assert(W1.GetStatus() == WindowOpen);
	W2.Open();
	assert(W2.GetStatus() == WindowOpen);

	// Load the images
	W1Bmp.Load("c1.bmp");
	assert(W1Bmp.GetStatus() == BitMapOkay);
	W2Bmp.Load("c2.bmp");
	assert(W2Bmp.GetStatus() == BitMapOkay);

	// Display the bit maps at a starting position
	W1Bmp.SetPosition(Position(1.0, 1.0));
	W2Bmp.SetPosition(Position(1.0, 1.0));
	W1Bmp.Draw();
	W2Bmp.Draw();

	// Register the callbacks for each window
	// and start the timers to go off every 500 ms
	W1.SetTimerCallback(W1TimerEvent);
	W2.SetTimerCallback(W2TimerEvent);
	bool TimerStatus1 = W1.StartTimer(500);
	bool TimerStatus2 = W2.StartTimer(500);
	assert(TimerStatus1 && TimerStatus2);

	return 0;
}

int ApiEnd() {
	// Stop the timers and close the windows
	W1.StopTimer();
	W2.StopTimer();
	W1.Close();
	W2.Close();

	return 0;
}


