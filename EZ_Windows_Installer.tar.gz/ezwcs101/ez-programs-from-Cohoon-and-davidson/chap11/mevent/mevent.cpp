//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: $
//
//**************************************************************************

// Example showing use of the mouse
// The program displays a bitmap in the window at
// the place where the mouse is click

#include <assert.h>
#include "bitmap.h"


// Define two non-overlapping windows
SimpleWindow W1("Window One", 15.0, 9.0,
 Position(1.0, 1.0));

SimpleWindow W2("Window Two", 15.0, 9.0, 
 Position(8.0, 12.0));

// Define two bitmaps, one for each window
BitMap W1Bmp(W1);
BitMap W2Bmp(W2);

// W1MouseClick(): call back function for Window one
int W1MouseClick(const Position &p) {

	// Erase the bitmap
	W1Bmp.Erase();

	// Set its new position and display it
	W1Bmp.SetPosition(p);
	W1Bmp.Draw();

	return 1;
}

// W2MouseClick(): call back function for Window two
int W2MouseClick(const Position &p) {

	// Erase the bitmap
	W2Bmp.Erase();

	// Set its new position and display it
	W2Bmp.SetPosition(p);
	W2Bmp.Draw();

	return 1;
}

int ApiMain() {

	// Open the windows
	W1.Open();
	assert(W1.GetStatus() == WindowOpen);
	W2.Open();
	assert(W2.GetStatus() == WindowOpen);

	// Load the images
	W1Bmp.Load("c1.bmp");
	assert(W1Bmp.GetStatus() == BitMapOkay);
	W2Bmp.Load("c2.bmp");
	assert(W2Bmp.GetStatus() == BitMapOkay);

	// Display the bit maps at a starting position
	W1Bmp.SetPosition(Position(1.0, 1.0));
	W2Bmp.SetPosition(Position(1.0, 1.0));
	W1Bmp.Draw();
	W2Bmp.Draw();

	// Register the call backs for each window
	W1.SetMouseClickCallback(W1MouseClick);
	W2.SetMouseClickCallback(W2MouseClick);

	return 0;
}

int ApiEnd() {
	// Close the windows
	W1.Close();
	W2.Close();

	return 0;
}




