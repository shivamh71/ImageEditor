//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include "qsort.h"

// QuickSort(): a recursive partitioning-based sort
void QuickSort(vector<char> &A, int left, int right) {
	if (left < right) {
		Pivot(A, left, right);
		int k = Partition(A, left, right);
		QuickSort(A, left, k-1);
		QuickSort(A, k+1, right);
	}
}

// Pivot(): prepare A for partitioning
void Pivot(vector<char> &A, int left, int right) {
	if (A[left] > A[right])
		Swap(A[left], A[right]);
}

// Partition(): rearrange A into 3 sublists, a sublist 
// A[left] � A[j-1] of values at most A[j], a sublist A[j],
// and a sublist A[j+1] � A[right] of values at least A[j]
int Partition(vector<char> &A, int left, int right) {
	char pivot = A[left];
	int i = left;
	int j = right+1;
	do {
		do ++i; while (A[i] < pivot);
		do --j; while (A[j] > pivot);
		if (i < j) {
			Swap(A[i], A[j]);
		}
	} while (i < j);
	Swap(A[j], A[left]);
	return j;
}

// Swap(): interchange elements
void Swap(char &Value1, char &Value2) {
	char RememberValue1 = Value1;
	Value1 = Value2;
	Value2 = RememberValue1;
}
