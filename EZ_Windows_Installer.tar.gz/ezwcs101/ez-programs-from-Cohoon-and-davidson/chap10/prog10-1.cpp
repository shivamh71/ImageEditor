//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Display inputs in reverse order
#include <iostream.h>

void GetList(int A[], int MaxN, int &n);
void Swap(int &Value1, int &Value2);
void PutList(const int A[], int n);

// main(): manage extraction, reversal, and display of list
int main() {
	const int MaxListSize = 100;
	int Number[MaxListSize];
	int n;
	GetList(Number, MaxListSize, n);
	for (int i = 0; i < n/2; ++i) {
		// swap element from front of list with
		// corresponding element from the end of the list
		Swap(Number[i], Number[n-1-i]);
	}
	PutList(Number, n);
	return 0;
}

// GetList(): extract up to MaxN value from input into A
void GetList(int A[], int MaxN, int &n) {
	for (n = 0; (n < MaxN) && (cin >> A[n]);++n) {
		continue;
	}
}

// Swap(): interchange values of parameters
void Swap(int &Value1, int &Value2) {
	int RememberValue1 = Value1;
	Value1 = Value2;
	Value2 = RememberValue1;
}

// PutList(): display n elements of A
void PutList(const int A[], int n) {
	for (int i = 0; i < n; ++i) {
		cout << A[i] << endl;
	}
}


