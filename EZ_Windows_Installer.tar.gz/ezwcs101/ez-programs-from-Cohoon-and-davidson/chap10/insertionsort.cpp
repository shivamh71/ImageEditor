//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.1 $
// $Name: E2 $
//
//**************************************************************************

// InsertionSort(): sort A using a shifting process
void InsertionSort(char A[], int n) {
	for (int i = 1; i < n; ++i) {
		// find proper spot for A[i]
		if (A[i] < A[i-1]) {
			// some shifting is necessary
			char v = A[i];			// copy A[i] so its spot can
										// be used for shifting
			int j = i;				// set up index where
										// available element spot
										// is located
			do {
				A[j] = A[j-1];		// do the value shift
				--j;					// prepare for next
										// comparison
			} while ((j > 0) && (A[j-1] > v));
			A[j] = v;							// put v in its spot
		}
	}
}
