//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#include <vector>
#include <string>
#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>

void PuzzleSearch(const vector< vector<char> > &T, const string &Word);
bool CheckWord(const vector< vector<char> > &T, int i, int j,
 const string &Word, int RowOffset, int ColOffset);



// main(): manage play of puzzle search game
int main() {
	string Filename;

	cout << "Enter puzzle table file name: " ;
	cin >> Filename;

	ifstream fin(Filename.c_str());

	vector< vector<char> > Table(1);// initially 1 row

	string s;

	while (fin >> s) {
		vector<char> v(s.length() + 2);
		v[0] = '\0';
		v[1 + s.length()] = '\0';
		for (int i = 0; i < s.length(); ++i) {
			v[i+1] = s[i];
		}
		Table.push_back(v);
	}

	vector<char> null(Table[1].size() + 2, '\0');

	Table[0] = null;
	Table.push_back(null);

	for (int i = 1; i < Table.size() - 1; ++i) {
		for (int j = 1; j <= Table[i].size(); ++j) {
			cout << Table[i][j];
		}
		cout << endl;
	}
	cout << endl;

	cout << "Enter your puzzle search word: ";

	while (cin >> s) {
		cout << endl;

		PuzzleSearch(Table, s);

		cout << endl;
		cout << "Enter your next search word: ";
	}

	return 0;
}



// PuzzleSearch(): look for Word in T
void PuzzleSearch(const vector< vector<char> > &T, const string &Word) {

	for (int i = 1; i < T.size() - 1; ++i) {
		for (int j = 1; j < T[i].size() - 1; ++j) {
			if (CheckWord(T, i, j, Word, 0, 1)) {
				cout << Word << " is at " << i << ", " << j
				<< " going horizontally right" << endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, 0, -1)) {
				cout << Word << " is at " << i << ", " << j
				<< " going horizontally left" << endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, 1, 0)) {
				cout << Word << " is at " << i << ", " << j
				<< " going vertically down" << endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, -1, 0)) {
				cout << Word << " is at " << i << ", " << j
				<< " going vertically up" << endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, 1, 1)) {
				cout << Word << " is at " << i << ", " << j
				<< " going diagonally right and down"
				<< endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, 1, -1)) {
				cout << Word << " is at " << i << ", " << j
				<< " going diagonally left and down"
				<< endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, -1, 1)) {
				cout << Word << " is at " << i << ", " << j
				<< " going diagonally right and up"
				<< endl;
				return;
			}
			else if (CheckWord(T, i, j, Word, -1, -1)) {
				cout << Word << " is at " << i << ", " << j
				<< " going diagonally left and up"
				<< endl;
				return;
			}
		}
	}
	cout << Word << " is not in the Puzzle" << endl;
	return;
}


// CheckWord(): look for Word in T starting at [i][j]
// changing row value by RowOffset and column value by
// ColOffset
bool CheckWord(const vector< vector<char> > &T, int i,
 int j, const string &Word, int RowOffset, int ColOffset) {
	int row = i;
	int col = j;
	for (int k = 0; k < Word.size(); ++k) {
		if (Word[k] != T[row][col])
			return false;
		else {
			row += RowOffset;
			col += ColOffset;
		}
	}
	return true;
}



