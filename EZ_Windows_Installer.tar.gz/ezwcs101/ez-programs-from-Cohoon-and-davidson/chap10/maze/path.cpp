//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.1 $
// $Name: E2 $
//
//**************************************************************************

#include <algorithm>
#include <iostream>
#include <string>
using namespace std;

#include "path.h"
// Constructor 
Path::Path(const Location &p) : CurrSeq(1, p) {
	// no body needed
}
// Inspector 
bool Path::Contains(const Location &p) const {
	if (find(CurrSeq.begin(), CurrSeq.end(), p)
	!= CurrSeq.end())
		return true;
	else
		return false;
}
// Mutator 
void Path::Append(const Location &p) {
	CurrSeq.push_back(p);
}

