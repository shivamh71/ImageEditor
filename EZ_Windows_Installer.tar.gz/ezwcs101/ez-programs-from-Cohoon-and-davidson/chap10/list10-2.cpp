//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.1 $
// $Name: E2 $
//
//**************************************************************************

#include <vector>
#include <string>

void GetList(vector<int> &A) {
	int n = 0;
	while ( (n < A.size()) && (cin >> A[n])) {
		++n;
	}
	A.resize(n);
}
void PutList(vector<int> &A) {
	for (int i = 0; i < A.size(); ++i) {
		cout << A[i] << endl;
	}
}
void GetValues(vector<int> &A) {
	A.resize(0);
	int Val;
	while (cin >> Val) {
		A.push_back(Val);
	}
}
