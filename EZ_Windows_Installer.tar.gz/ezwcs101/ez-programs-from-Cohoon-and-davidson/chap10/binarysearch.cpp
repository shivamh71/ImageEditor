//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include <vector>

// BinarySearch(): examine sorted list A for Key
int BinarySearch(vector<char> &A, char Key) {
	int left = 0;
	int right = A.size() - 1;
	while (left <= right) {
		int mid = (left + right)/2;
		if (A[mid] == Key)
			return mid;
		else if (A[mid] < Key)
			left = mid + 1;
		else
			right = mid - 1;
	}
	return A.size();
}

