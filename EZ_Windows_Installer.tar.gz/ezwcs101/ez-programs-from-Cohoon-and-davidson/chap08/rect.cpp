//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include "rect.h"

RectangleShape::RectangleShape(SimpleWindow &w,
 float x, float y, color c,
 float l, float h) : Window(w),
 XCenter(x), YCenter(y), Color(c),
 Length(l), Height(h) {
}

void RectangleShape::Draw() {

	const Position Center = Position(XCenter, YCenter);

	Position UpperLeft = Center
	 + Position(-(.5 * Length), -(.5 * Height));
	Position LowerRight = Center
	 + Position(.5 * Length, .5 * Height);
	Window.RenderRectangle(UpperLeft, LowerRight,
	 Color, true);
}

color RectangleShape::GetColor() const {
	return Color;
}

void RectangleShape::GetSize(float &l,
 float &h) const {
	l = Length;
	h = Height;
}

void RectangleShape::GetPosition(float &x,
 float &y) const {
	x = XCenter;
	y = YCenter;
}

SimpleWindow& RectangleShape::GetWindow() const {
	return Window;
}

void RectangleShape::SetColor(const color c) {
	Color = c;
}

void RectangleShape::SetPosition(float X, float Y) {
	XCenter = X;
	YCenter = Y;
}

void RectangleShape::SetSize(float L, float H) {
	Length = L;
	Height = H;
}


