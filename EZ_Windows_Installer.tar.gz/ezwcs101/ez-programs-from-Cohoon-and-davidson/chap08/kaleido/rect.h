//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.1 $
// $Name: E2 P2 P1 $
//
//**************************************************************************

#ifndef RECTSHAPE_H
#define RECTSHAPE_H
#include "ezwin.h"
class RectangleShape {
	public:
		RectangleShape(SimpleWindow &Window,
		 float XCoord, float YCoord,
		 color Color,
		 float Length, float Height);
		void Draw();
		color GetColor() const;
		void GetSize(float &Length, float &Height) const;
		void GetPosition(float &XCoord, float &YCoord) const;
		SimpleWindow& GetWindow() const;
		void SetColor(const color Color);
		void SetPosition(float XCoord, float YCoord);
		void SetSize(float Length, float Height);
	private:
		SimpleWindow &Window;
		float XCenter;
		float YCenter;
		color Color;
		float Length;
		float Height;

};
#endif
