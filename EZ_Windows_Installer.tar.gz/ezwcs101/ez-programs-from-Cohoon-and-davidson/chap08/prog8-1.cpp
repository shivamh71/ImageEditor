// Program 8.1: Display color palette
#include "rect.h"

SimpleWindow ColorWindow("Color Palette", 8.0, 8.0);
int ApiMain() {

	const float SideSize = 1.0;
	float XPosition = 1.5;
	const float YPosition = 4;

	ColorWindow.Open();

	// Create a RectangleShape to use
	RectangleShape ColorPatch(ColorWindow,
	 XPosition, YPosition, White, SideSize, SideSize);

	// Loop over colors drawing ColorSquare with
	// that color next to the previous square
	for (color c = Red; c <= Magenta;
	 c = (color) (c + 1)) {
		ColorPatch.SetColor(c);
		ColorPatch.SetPosition(XPosition, YPosition);
		ColorPatch.Draw();
		XPosition += SideSize;
	}
	return 0;
}
