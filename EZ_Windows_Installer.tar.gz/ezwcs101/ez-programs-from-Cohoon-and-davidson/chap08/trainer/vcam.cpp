//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#include <assert.h>
#include "vcam.h"
#include "uniform.h"

// Randomly pick one of the six colors
color GenerateRandomColor() {
	switch (Uniform(0, 5)) {
		case 0: return Red;
		case 1: return Blue;
		case 2: return Green;
		case 3: return Yellow;
		case 4: return Cyan;
		case 5: return Magenta;
	}
	return Yellow;
}

VideoCamera::VideoCamera() : Status(CameraOff) {
	// No code needed
}

CameraStatus VideoCamera::GetStatus() const {
	return Status;
}

VideoImage VideoCamera::CaptureImage() {
	VideoImage v(GenerateRandomColor(), GenerateRandomColor(),
	 GenerateRandomColor());
	// Just return v, instantiation did everything!
	return v;
}

void VideoCamera::TurnOn() {
	Status = CameraOn;
}

void VideoCamera::TurnOff() {
	Status = CameraOff;
}
