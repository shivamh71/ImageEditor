//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include "image.h"

VideoImage::VideoImage(const color &c1, const color &c2,
 const color &c3) : Part1(c1), Part2(c2), Part3(c3) {
   // No code needed
}

Part VideoImage::GetPart1() const {
	return Part1;
}

Part VideoImage::GetPart2() const {
	return Part2;
}

Part VideoImage::GetPart3() const {
	return Part3;
}
