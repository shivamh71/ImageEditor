//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include <iostream.h>
#include "console.h"

Console::Console() : Status(ConsoleOff) {
	// No code needed
};
void Console::TurnOn() {
	Status = ConsoleOn;
	// Print message telling user to arrange windows
	cout << "Please resize this window so that\n"
	 << "that both windows are visible,\n"
	 << "and they do not overlap.\n"
	 << "Type any character followed by a return\n"
	 << "when you are ready to proceed" << endl;
	char Response;
	cin >> Response;

	cout << "\n\n\n" << flush;
}

char Console::GetResponse() {
	char c;
   cout << "Accept or reject (a or r)? " << flush;
	cin >> c;
	return c;
}

void Console::PrintSessionResults(long Time, int Attempts,
		 int Correct, int Wrong) {
	cout << "\n\nFor a training period of "
	 << Time / 1000L << " seconds" << endl;
	cout << "Groups viewed: " << Attempts << endl;
	cout << "Correct responses: " << Correct << endl;
	cout << "Incorrect responses: " << Wrong << endl;
	cout << "Percent correct: "
	 << Correct / (float) Attempts * 100 << endl;

	return;
}

void Console::TurnOff() {
	Status = ConsoleOff;
}

