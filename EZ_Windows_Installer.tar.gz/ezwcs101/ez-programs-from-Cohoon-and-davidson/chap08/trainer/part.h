//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#ifndef PART_H
#define PART_H
#include "ezwin.h"

class Part {
	public:
		Part(const color &c = Red);
		color GetColor() const;
	private:
		color Color;
};
#endif
