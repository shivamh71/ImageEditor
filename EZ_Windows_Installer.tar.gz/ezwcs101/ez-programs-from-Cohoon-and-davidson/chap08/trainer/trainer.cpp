//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include <iostream.h>
#include "uniform.h"
#include "dunit.h"
#include "ezwin.h"
#include "vcam.h"
#include "console.h"

// Length of the session (60 seconds)
const long TestTime = 60 * 1000L;

// Determine if the appropriate response was given
bool CheckResponse(char Response,
 const VideoImage &v) {
	Part Part1 = v.GetPart1();
	Part Part2 = v.GetPart2();
	Part Part3 = v.GetPart3();
	if (Part1.GetColor() == Part2.GetColor()
	 || Part1.GetColor() == Part3.GetColor()
	 || Part2.GetColor() == Part3.GetColor())
		return Response == 'a';
	else
		return Response == 'r';
}

int ApiMain() {
	VideoDisplayUnit TrainingMonitor("TRAINING DISPLAY");
	VideoCamera InspectionCamera;
	Console TrainingConsole;
	TrainingMonitor.TurnOn();
	TrainingConsole.TurnOn();
	InspectionCamera.TurnOn();

	InitializeSeed();
	// Define objects for scoring the trainee
	int Attempts = 0;   // Number of tests done
	int CorrectResponses = 0;
	int IncorrectResponses = 0;

	// Record starting time
	const long StartTime = GetMilliseconds();
	long ElapsedTime;

	do {
		VideoImage Image = InspectionCamera.CaptureImage();
		TrainingMonitor.DisplayImage(Image);

		char Response;
		Response = TrainingConsole.GetResponse();

		++Attempts;
		if (CheckResponse(Response, Image))
			++CorrectResponses;
		else
			++IncorrectResponses;
		ElapsedTime = GetMilliseconds();
	} while ((ElapsedTime - StartTime) < TestTime);

	TrainingConsole.PrintSessionResults(TestTime,
	 Attempts, CorrectResponses, IncorrectResponses);
	TrainingMonitor.TurnOff();
	TrainingConsole.TurnOff();
	InspectionCamera.TurnOff();
	return 0;
}
