//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

#ifndef DISPLAYUNIT_H
#define DISPLAYUNIT_H
#include <string>
#include "ezwin.h"
#include "image.h"

enum DisplayStatus { DisplayOn, DisplayOff };
class VideoDisplayUnit {
	public:
		VideoDisplayUnit(const string &Title);
		void DisplayImage(const VideoImage &Image);
		void TurnOn();
		void TurnOff();
	private:
		SimpleWindow W;
		DisplayStatus Status;
};
#endif
