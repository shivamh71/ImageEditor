//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

#include "dunit.h"
#include "./rect.h"

// Length and height of display window
const float DisplayLength = 14.0;
const float DisplayHeight = 6.0;

// Vertical position of parts
const float YPosition = DisplayHeight / 2.0;

// Part size for display
const float PartSize = 2.0;

VideoDisplayUnit::VideoDisplayUnit(const string &Title) : W(Title.c_str(),
 DisplayLength, DisplayHeight) {
}

void VideoDisplayUnit::DisplayImage(const VideoImage &v) {
	RectangleShape R1(W, 3, YPosition, v.GetPart1().GetColor(),
	 PartSize, PartSize);
	R1.Draw();
	RectangleShape R2(W, 7, YPosition, v.GetPart2().GetColor(),
	 PartSize, PartSize);
	R2.Draw();
	RectangleShape R3(W, 11, YPosition, v.GetPart3().GetColor(),
	 PartSize, PartSize);
	R3.Draw();
}

void VideoDisplayUnit::TurnOn() {
	W.Open();
	Status = DisplayOn;
}

void VideoDisplayUnit::TurnOff() {
	Status = DisplayOff;
}
