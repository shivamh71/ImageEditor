//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.3 $
// $Name: E2 $
//
//**************************************************************************

// Determines roots of a quadratic equation
#include <iostream.h>
#include <math.h>

int main() {
	cout << "Coefficients for quadratic equation: ";
	double a;
	double b;
	double c;
	cin >> a >> b >> c;
	if ((a != 0) && ((b*b - 4*a*c) > 0)) {
		double radical = sqrt(b*b - 4*a*c);
		double root1 = (-b + radical) / (2*a);
		double root2 = (-b - radical) / (2*a);
		cout << "The roots of " << a << "x**2 + " << b
		<< "x + " << c << " are " << root1 << " and " 
		<< root2 << endl;
	}
	else {
		cout <<  a << "x**2 + " << b << "x + " << c
		 << " does not have two real roots" << endl;
	}
	return 0;
}


