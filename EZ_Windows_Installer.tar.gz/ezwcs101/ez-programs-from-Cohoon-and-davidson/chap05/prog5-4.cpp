//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2.1.3 $
// $Name: E2 $
//
//**************************************************************************

// NOTE: Be aware that some compilers have not yet implemented the "fixed"
//  manipulator.

// Displays the results of various functions
#include <iostream.h>
#include <iomanip.h>
#include <math.h>

int main() {
	const int ColWidth = 9;
	double x = 1;
	cout
	<< setw(ColWidth) << "x" << setw(ColWidth) << "ln"
	<< setw(ColWidth) << "log" << setw(ColWidth)
	<< "cuberoot" << setw(ColWidth) << "sqrt" << endl;
	cout << setfill('=') << setw(5*ColWidth) << "=" << endl;
	cout << setfill(' ');
	while (x  < 1000000)  {
		cout << setprecision(0) 
		<< setw(ColWidth) << x << setprecision(4)
		<< setw(ColWidth) << log(x)
		<< setw(ColWidth) << log10(x)
		<< setw(ColWidth) << pow(x,1.0/3.0)
		<< setw(ColWidth) << sqrt(x)
		<< endl;
		if (x < 10) {
			++x;
		}
		else if (x < 100) {
			x += 10;
		}
		else {
			x *= 10;
		}
	}
	return 0;
}


