//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.2.1.2 $
// $Name: E2 $
//
//**************************************************************************

// Prompts user for a file and then calculates
// the average of the values in that file
#include <string>
#include <fstream.h>
#include <iostream.h>
#include <stdlib.h>

int main() {
	cout << "File of values to be averaged: ";
	string FileName;
	cin >> FileName;
	ifstream fin(FileName.c_str());
	if (! fin) {
		cerr << "Cannot open " << FileName
		<< " for averaging." << endl;
		exit(1);
	}
	int ValuesProcessed = 0;
	float ValueSum = 0;
	float Value;
	while (fin >> Value) {
		ValueSum += Value;
		++ValuesProcessed;
	}
	if (ValuesProcessed > 0) {
		float Average = ValueSum / ValuesProcessed;
		cout << "Average of values from " << FileName
		<< " is " << Average << endl;
	}
	else {
		cerr << "No values to average in "
		<< FileName << endl;
		exit(1);
	}
	return 0;
}
