//**************************************************************************
//
// Copyright (c) 1997-1999.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/1/98
// $Revision: 1.4 $
// $Name: E2 $
//
//**************************************************************************

// Calculates average of file mydata.nbr
#include <iostream.h>
#include <fstream.h>

int main() {
	ifstream fin("mydata.nbr");
	int ValuesProcessed = 0;
	float ValueSum = 0;
	float Value;
	while (fin >> Value) {
		ValueSum += Value;
		++ValuesProcessed;
	}
	if (ValuesProcessed > 0) {
		ofstream fout("average.nbr");
		float Average = ValueSum / ValuesProcessed;
		fout << "Average: " << Average << endl;
	}
	else {
		cerr << "No list to average" << endl;
	}
	return 0;
}



