/*   C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay
    
s3.cpp  
     Program to illustrat drawing points (Could be any data)
     at random locations, along with a label in a window. 
  
     A point is approximated by a small object of 
     rectangular shape (size 0.1 x 01 cm)
     
 */
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cstdio>
using namespace std;
#include "rect.h"
#include "label.h"

int DimensionX, DimensionY;

void WrapUp(SimpleWindow &z) {
  cout << "Type Ctrl-C to remove the display and exit" << endl;
  char AnyChar;
  cin >> AnyChar;
  z.Close();
}

void generateData(int x[][2], int size) {
  for (int i = 0; i < size; ++i){
    x[i][0] =   rand() % DimensionX;
    x[i][1] =   rand() % DimensionY;
    cout << "(" << x[i][0] << "," << x[i][1] << ") ";
  }
  cout << endl;
}

void displayData(SimpleWindow &z, int ecgSignal[][2], int size) {
  for (int i = 0; i < size; ++i) {
    int x = ecgSignal[i][0];
    int y = ecgSignal[i][1];
    RectangleShape Point(z, x, y, Blue, 0.1, 0.1);
    Point.Draw();
    char mystring[80];
    // Print label information onto a string
    sprintf(mystring, "%2d at %2d,%2d", i,x,y);  
    Label Item(z, x+ 0.2, y + 0.2, mystring);
    Item.Draw();
  }
}

int ApiMain() {  
  int xPoints;
  srand((unsigned int) time(0));
  cout << "Enter width and height for the window): ";
  cin >> DimensionX >> DimensionY;
  cout <<"How many points do you wish to generate: ";
  cin >> xPoints;
  SimpleWindow w("Random Points", DimensionX, DimensionY);
  w.Open();
  int data[xPoints][2];
  generateData(data, xPoints);
  displayData(w, data, xPoints);
  WrapUp(w);
  return 0;
}
