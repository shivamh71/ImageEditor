#include "ezwin.h"

// Create a 10 x 4 window
SimpleWindow HelloWindow("CS101 Graphic Window", 10.0, 5.0, Position(15.0, 6.0));
// ApiMain(): create a window and display greeting
int ApiMain() {
  HelloWindow.Open();
  HelloWindow.RenderText(Position(3.0,2.0), Position(7.0,3.0), "Namaste CS101 students", White);
  char somechar;
  cout << "press any key to exit\n";
  cin >> somechar;
  HelloWindow.Close();
  return 0;
}
