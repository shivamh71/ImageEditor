/*   CS 101, Autumn Semester 2010-11
     C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original in the EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay


     sample4.cpp
     demonstrates pattern created by lines drawn 
     between varying start and end points      
 */

#include <ezwin.h>
#include <cassert>
#include "rect.h"

// Create a 10cm x 10cm window, with title "Lines"
SimpleWindow MyWindow("Lines", 10.0, 10.0,
                       Position(3.0, 1.0));

int ApiMain() {
  MyWindow.Open();
  assert(MyWindow.GetStatus() == WindowOpen);

  float x,y;
  float i,j;

  // Some Lines creating interesting pattern

  for(x=0.0;x<10.0;x+=0.2) {
    MyWindow.RenderLine(Position(x,0.0), Position(0.0,10.0-x),
                        Black, 0.0);
    MyWindow.RenderLine(Position(10.0,x), Position(10.0-x,10.0),
                        Red, 0.0);
  }    
}
