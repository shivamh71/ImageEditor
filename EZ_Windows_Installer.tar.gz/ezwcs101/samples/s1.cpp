/*   C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors Prof Milind Sohoni, 
     Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay     


s1.cpp  
    Opening a graphic window with default attributes
*/
#include <iostream>
#include "ezwin.h"
using namespace std;  

int ApiMain() {
  SimpleWindow w("My first window", 25, 20);
  w.Open();
  cout << "Type Ctrl-C to remove the display and exit" << endl;
  char AnyChar;
  cin >> AnyChar;
  w.Close();
  return 0;
}
