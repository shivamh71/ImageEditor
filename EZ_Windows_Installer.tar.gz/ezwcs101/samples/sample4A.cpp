/*   CS 101, Autumn Semester 2010-11
     C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original in the EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay


     sample4.cpp
     demonstrates pattern created by lines drawn 
     between varying start and end points      
 */

#include <ezwin.h>
#include <cassert>
#include "rect.h"
#include <cmath>

// Create a 10cm x 10cm window, with title "Lines"
SimpleWindow MyWindow("Graph for sin(x)", 10.0, 10.0,
                       Position(1.0, 1.0));

int ApiMain() {
  MyWindow.Open();
  assert(MyWindow.GetStatus() == WindowOpen);
  float x,y, rad;
  //Draw x and Y axis
    MyWindow.RenderLine(Position(0.1,0.1), Position(0.1, 10),
                        Black, 0.0);
    MyWindow.RenderLine(Position(0.1, 5), Position(10, 5),
                        Black, 0.0);  
  rad = 3.14159/5; // 2 pi should be equal to 10
  for(x=0.0;x<10.0;x+=0.001) {
    y = sin(x*rad); // y is between -1 and 1
    y = 3*y;       // scale it from -3 to 3
    MyWindow.RenderLine(Position(x+0.1,y+5), Position(x+0.1, y+5),
                        Blue, 0.0);
  
  }    
  return 0;
}
