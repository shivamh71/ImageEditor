/*   C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay
   
   
s2.cpp : 
    Illustrates opening a window of specified size 
    drawn at specified position, and displaying a text 
    string in the window
 */
#include "ezwin.h"
#include <cassert>
	// Define a 15 x 10 window
	SimpleWindow HW("CS101 Window", 15.0, 10.0, Position(1.0, 1.0));

int ApiMain() {

HW.Open();
	// Get Center of Window
	Position Center = HW.GetCenter();

	// Create bounding box for text
	Position UpperLeft = Center + Position(-1.0, -1.0);
	Position LowerRight = Center + Position(1.0,  1.0);

	// Display the text
	HW.RenderText(UpperLeft, LowerRight,
	 "Namaste CS101 students", Red);
	 sleep(10);
	return 0;
}
