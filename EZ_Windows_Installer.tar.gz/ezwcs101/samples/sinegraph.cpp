/*   sinegraph.cpp
     Illustration of graph plotting
     Plots sin(x)
 
 */

#include <ezwin.h>
#include <cassert>
#include "rect.h"
#include <cmath>

// Create a 10cm x 10cm window, with title "Lines"
SimpleWindow MyWindow("Graph for sin(x)", 20.0, 10.0,
                       Position(1.0, 1.0));

int ApiMain() {
  MyWindow.Open();
  assert(MyWindow.GetStatus() == WindowOpen);
  float x,y, rad;
  //Draw x and Y axis
    MyWindow.RenderLine(Position(0.5,0.1), Position(0.5, 10),
                        Black, 0.0);
    MyWindow.RenderLine(Position(0.1, 5), Position(10, 5),
                        Black, 0.0);  
  rad = 3.14159/5; // 2 pi should be equal to 10
  for(x=0.0;x<10.0;x+=0.001) {
    y = sin(x*rad); // y is between -1 and 1
    y = -3*y;       // scale it from -3 to 3
    MyWindow.RenderLine(Position(x+0.51,y+5.5), Position(x+0.1, y+5),
                        Blue, 0.0);
  
  }    
  return 0;
}
