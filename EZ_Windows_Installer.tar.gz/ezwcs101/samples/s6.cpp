/*   C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay
   
   
s6.cpp : 
    Illustrates opening a window and displaying various shapes
 */#include <iostream>
#include "ezwin.h"
#include "position.h"
#include "rect.h"
#include "circle.h"
#include "triangle.h"
#include "square.h"
#include "wobject.h"
#include "shape.h"
#include "bitmap.h"
#include "label.h"
using namespace std;
SimpleWindow W ("This is a drawing", 15, 15);
int ApiMain()
{
    char mychar;
    int myint;
    Position x[2];
    cout << "Welcome. Enter an integer ";
    cin >> myint;
    // These happen before you draw your window
    W.Open();
    RectangleShape R1 (W, 4, 7, Red, 5, 6);
    R1.Draw();
    RectangleShape R2 (W, 4, 7, Red, 2, 3);
    R2.Draw();
    R2.Erase();
    R2.ClearBorder();
    RectangleShape R3 (W, 9, 12, Red, 3, 1);
    R3.Draw();
    CircleShape C (W, Position (8, 5), Blue, 1);
    C.Draw();
    TriangleShape T(W, Position(8,3), Green, 4);
    T.Draw();
    W.RenderLine(Position(6.0,7.0), Position(10.0,10.0),Black,0.1);
    cout << "Welcome.  Enter a character ";
    cin >> mychar; // these happen after you draw
    W.Close();
    return 0;
}
