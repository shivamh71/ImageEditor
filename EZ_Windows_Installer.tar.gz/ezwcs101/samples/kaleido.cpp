//**************************************************************************
//
// Copyright (c) 1997.
//      Richard D. Irwin, Inc.
//
// This software may not be distributed further without permission from
// Richard D. Irwin, Inc.
//
// This software is distributed WITHOUT ANY WARRANTY. No claims are made
// as to its functionality or purpose.
//
// Authors: James P. Cohoon and Jack W. Davidson
// Date: 7/15/96
// $Revision: 1.2 $
// $Name: E2 $
//
//**************************************************************************

// Program 8.2: Simulate a simple kaleidoscope
#include "uniform.h"
#include "rect.h"

// Size of the window
const float WindowSize = 10.0;

// Maximum size of a trinket
const float MaxSize = 4.0;

// Create a square window
SimpleWindow KaleidoWindow("Kaleidoscope",
 WindowSize, WindowSize);

color RandomColor() {
	return (color) Uniform(0, MaxColors - 1);
}

// RandomOffset - generate a random amount to offset
// a trinket from the center of the window. Generate
// a random offset in the interval 0..Range-1 in
// .1-centimeter increments. The size of the offset
// must take into account the size of the trinket so 
// the shapes do not overlap at the center.
float RandomOffset(int Range, float TrinketSize) {
	float Offset = Uniform(0, Range * 10) / 10.0;
	if (Offset < TrinketSize / 2)
		Offset = TrinketSize / 2;
	return Offset;
}

// RandomSize - generate a random size in
// the interval 1 to MaxSize in .1-centimeter
// increments (i.e., 1, 1.1, 1.2, ..., MaxSize)
float RandomTrinketSize(int MaxSize) {
	return Uniform(10, MaxSize * 10) / 10.0;
}

int Kaleidoscope() {

	const float Center = WindowSize / 2.0;

	const float TrinketSize = RandomTrinketSize((int)MaxSize);
	float Offset = RandomOffset((int)MaxSize, TrinketSize);
	const color FirstColor = RandomColor();
	const color SecondColor = RandomColor();

	// Create four trinkets, one in each quadrant
	RectangleShape TrinketQuad1(KaleidoWindow,
	 Center + Offset, Center + Offset, FirstColor,
	 TrinketSize, TrinketSize);
	RectangleShape TrinketQuad2(KaleidoWindow,
	 Center - Offset, Center + Offset, SecondColor,
	 TrinketSize, TrinketSize);
	RectangleShape TrinketQuad3(KaleidoWindow,
	 Center - Offset, Center - Offset, FirstColor,
	 TrinketSize, TrinketSize);
	RectangleShape TrinketQuad4(KaleidoWindow,
	 Center + Offset, Center - Offset, SecondColor,
	 TrinketSize, TrinketSize);

	// Draw the trinkets
	TrinketQuad1.Draw();
	TrinketQuad2.Draw();
	TrinketQuad3.Draw();
	TrinketQuad4.Draw();

	// Reset their color
	TrinketQuad1.SetColor(SecondColor);
	TrinketQuad2.SetColor(FirstColor);
	TrinketQuad3.SetColor(SecondColor);
	TrinketQuad4.SetColor(FirstColor);

	// Relocate the trinkets to a new position for
	// a Kaleidoscope effect
	Offset = RandomOffset((int)MaxSize, TrinketSize);
	TrinketQuad1.SetPosition(Center + Offset,
	 Center + Offset);
	TrinketQuad2.SetPosition(Center - Offset,
	 Center + Offset);
	TrinketQuad3.SetPosition(Center - Offset,
	 Center - Offset);
	TrinketQuad4.SetPosition(Center + Offset,
	 Center - Offset);

	// Draw the trinkets at the new positions
	TrinketQuad1.Draw();
	TrinketQuad2.Draw();
	TrinketQuad3.Draw();
	TrinketQuad4.Draw();

	return 0;
}

int ApiMain() {
	InitializeSeed();
	KaleidoWindow.Open();
	KaleidoWindow.SetTimerCallback(Kaleidoscope);
	KaleidoWindow.StartTimer(1000);

	return 0;
}


