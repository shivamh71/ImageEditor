/*   CS 101, Autumn Semester 2010-11
     C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original in the EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay
   
   sample5.cpp
   draws different shapes in a single window   
 */

#include "ezwin.h"
#include <cassert>

// Define a window with title "Basic", size 10cm x 10cm,
//     positioned 3cm from left, 1cm from top of screen.
SimpleWindow MyWindow("Basic", 10.0, 10.0,
		      Position(3.0, 1.0));
int ApiMain() {
  MyWindow.Open();
  assert(MyWindow.GetStatus() == WindowOpen);

  // Colors: {White, Red, Green, Blue, Yellow, Cyan, Magenta};

  //Green Rectangle, with no border
  MyWindow.RenderRectangle(Position(1.0,1.0), Position(2.0,2.0),
			   Green, false);

  //Yellow Rectangle, with border
  MyWindow.RenderRectangle(Position(2.5,2.5), Position(5.0,6.0),
			   Yellow, true);

  //Red Line, thickness 0
  MyWindow.RenderLine(Position(3.0,0.0),Position(3.5,2.0),
		      Red,0.0);

  //Blue Ellipse, border=true
  MyWindow.RenderEllipse( Position(1.0,6.5),Position(4.0, 8.5),
			  Blue, true);

  return 0;
} // end ApiMain()
