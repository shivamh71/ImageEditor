/*   CS 101, Autumn Semester 2010-11
     C++ Programs for illustration
     Several programs are based on slides/material by
     earlier course instructors
     Prof Milind Sohoni, Prof S Sudarshan, and Prof Abhiram Ranade
     
     The sample programs on Graphics also use sample code
     in the original in the EzWindow documentation
     
     Compiled by Prof Deepak B Phatak, 
     dept of CSE, Kanwal Rekhi Building, IIT Bombay
   
   
    sample2.cpp : 
    Illustrates opening a window of specified size 
    drawn at specified position, and displaying a text 
    string in the window
 */
#include "ezwin.h"
#include <cassert>

// Define a 10 x 10 window
SimpleWindow HelloWindow("Hello EzWindows", 10.0, 10.0, Position(1.0, 1.0));
int ApiMain() {	HelloWindow.Open();
	assert(HelloWindow.GetStatus() == WindowOpen);

	// Get Center of Window
	Position Center = HelloWindow.GetCenter();

	// Create bounding box for text
	Position UpperLeft = Center + Position(-1.0, -1.0);
	Position LowerRight = Center + Position(1.0,  1.0);

	// Display the text
	HelloWindow.RenderText(UpperLeft, LowerRight,
	 "Namaste CS101 students", Red);
	return 0;
}
